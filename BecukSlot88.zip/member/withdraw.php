<?php
session_start();
include '../config/database.php';
include '../config/security_helper.php';

// 1. Cek Login
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'member'){
    header("location:login.php");
    exit;
}

$id_member = $_SESSION['user_id'];

// 2. Ambil Data User (Saldo & Info Bank)
// Asumsi tabel users punya kolom: nama_rekening, nomor_rekening, nama_bank
$stmt = $koneksi->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id_member);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Jika data bank kosong (bisa disesuaikan dengan struktur db anda)
$bank_user = !empty($user['nama_bank']) ? $user['nama_bank'] : "BCA";
$rek_user  = !empty($user['nomor_rekening']) ? $user['nomor_rekening'] : "8820xxx (Default)";
$an_user   = !empty($user['nama_rekening']) ? $user['nama_rekening'] : $user['username'];

// 3. Cek Pending Lock (Satu transaksi WD per waktu)
$cek_pending = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_member' AND tipe_transaksi='keluar' AND status='pending' ORDER BY id DESC LIMIT 1");
$data_pending = mysqli_fetch_assoc($cek_pending);
$is_pending = ($data_pending != null);

// Variabel Alert
$alert_type = ""; 
$alert_message = "";

// 4. PROSES WITHDRAW
if(isset($_POST['submit_withdraw'])){
    cek_csrf();
    
    $nominal = (int)str_replace('.', '', $_POST['amount']);
    $min_wd = 50000; // Minimal WD standar nasional

    if($is_pending) {
        $alert_type = "error"; $alert_message = "Anda masih memiliki penarikan yang sedang diproses!";
    } elseif($nominal < $min_wd) {
        $alert_type = "warning"; $alert_message = "Minimal Penarikan Rp ".number_format($min_wd);
    } elseif($nominal > $user['saldo']) {
        $alert_type = "error"; $alert_message = "Saldo Anda tidak mencukupi!";
    } else {
        // A. Potong Saldo Dulu
        $sisa_saldo = $user['saldo'] - $nominal;
        $update_saldo = mysqli_query($koneksi, "UPDATE users SET saldo='$sisa_saldo' WHERE id='$id_member'");

        if($update_saldo){
            // B. Catat di History
            $keterangan = "Withdraw ke $bank_user ($rek_user)";
            $stmt = $koneksi->prepare("INSERT INTO riwayat_transaksi (user_id, tipe_transaksi, jumlah, keterangan, status, tanggal) VALUES (?, 'keluar', ?, ?, 'pending', NOW())");
            $stmt->bind_param("ids", $id_member, $nominal, $keterangan);
            
            if($stmt->execute()){
                $alert_type = "success";
                $alert_message = "Permintaan Withdraw Berhasil!\\nSaldo telah dipotong sementara. Dana akan masuk ke rekening Anda dalam 3-5 menit.";
                // Refresh data user agar saldo update di layar
                $user['saldo'] = $sisa_saldo;
                $is_pending = true; // Langsung kunci layar
                // Ambil data pending terbaru
                $cek_pending = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_member' AND tipe_transaksi='keluar' AND status='pending' ORDER BY id DESC LIMIT 1");
                $data_pending = mysqli_fetch_assoc($cek_pending);
            }
        } else {
            $alert_type = "error"; $alert_message = "Gagal update saldo.";
        }
    }
}

// 5. BATALKAN WITHDRAW (REFUND SALDO)
if(isset($_POST['batalkan_wd'])){
    cek_csrf();
    $id_trx = $_POST['id_transaksi'];
    
    // Ambil nominal transaksi yg mau dibatalkan
    $cek_trx = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE id='$id_trx' AND user_id='$id_member' AND status='pending'");
    $data_trx = mysqli_fetch_assoc($cek_trx);

    if($data_trx){
        $nominal_refund = $data_trx['jumlah'];
        
        // 1. Update Status Batal
        mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status='batal', keterangan=CONCAT(keterangan, ' (User Cancel)') WHERE id='$id_trx'");
        
        // 2. Kembalikan Saldo (Refund)
        mysqli_query($koneksi, "UPDATE users SET saldo = saldo + $nominal_refund WHERE id='$id_member'");
        
        echo "<script>alert('Penarikan dibatalkan. Saldo telah dikembalikan.'); window.location.href='withdraw.php';</script>";
    }
}

// History
$q_hist = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_member' ORDER BY id DESC LIMIT 10");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Withdraw - WINSORTOTO</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@400;600&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            background-color: #050505;
            background-image: url("https://myimagehost.me/assets/bg-m-winsor-natal.jpg");
            background-size: 100%; background-attachment: fixed;
            color: #fff; font-family: 'Roboto', sans-serif;
            margin: 0; padding: 0; padding-top: 110px; padding-bottom: 80px;
        }
        * { box-sizing: border-box; outline: none; -webkit-tap-highlight-color: transparent; }

        /* HEADER & SALDO (SAMA) */
        .header-saldo {
            background: linear-gradient(135deg, #1c1c1c 0%, #000 100%);
            border-top: 2px solid #ffd321; border-bottom: 2px solid #ffd321;
            padding: 10px 15px; margin: 0 5px 15px 5px; border-radius: 0 0 15px 15px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .user-label { font-size: 12px; color: #aaa; }
        .user-val { color: #ffd321; font-weight: bold; text-transform: uppercase; }
        .saldo-val { font-family: 'Teko', sans-serif; font-size: 22px; font-weight: 600; color: #fff; }

        /* FORM CARD */
        .form-card {
            background: #e5e5e5; color: #000; border-radius: 10px;
            margin: 0 10px 20px 10px; padding: 15px; border: 1px solid #fff;
        }
        .info-bank-card {
            background: linear-gradient(to right, #2c3e50, #4ca1af);
            color: #fff; padding: 15px; border-radius: 10px; margin-bottom: 20px;
            box-shadow: 0 5px 10px rgba(0,0,0,0.2); position: relative; overflow: hidden;
        }
        .info-bank-card::before {
            content: "BANK UTAMA"; position: absolute; top: 10px; right: 10px;
            font-size: 10px; background: rgba(0,0,0,0.3); padding: 2px 8px; border-radius: 4px;
        }
        .bank-name { font-size: 20px; font-weight: bold; font-family: 'Teko', sans-serif; margin-bottom: 5px; display: block; }
        .rek-num { font-size: 18px; letter-spacing: 2px; font-family: monospace; display: block; margin-bottom: 5px; }
        .acc-name { font-size: 12px; text-transform: uppercase; opacity: 0.9; }

        .form-row { display: flex; align-items: center; padding: 10px 0; border-bottom: 1px solid #ccc; }
        .label-col { width: 35%; font-weight: bold; color: #444; font-size: 13px; }
        .val-col { width: 65%; font-weight: bold; color: #000; font-size: 14px; }
        .input-nominal { width: 100%; padding: 8px; border: 1px solid #999; border-radius: 5px; font-weight: bold; font-size: 14px; }

        /* TOMBOL */
        .btn-submit {
            width: 100%; padding: 15px; background: #d32f2f; color: #fff; /* Merah untuk WD */
            border: none; border-radius: 8px; font-weight: bold; font-size: 16px;
            cursor: pointer; margin-top: 15px; text-transform: uppercase;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2); transition: all 0.2s;
        }
        .btn-submit:active { transform: scale(0.98); }

        /* PENDING LOCK */
        .pending-lock {
            background: linear-gradient(to right, #1a1a1a, #000);
            border: 1px solid #ffca28; border-radius: 10px;
            padding: 30px 20px; text-align: center; margin: 20px 10px;
        }
        .pending-amount { font-size: 36px; color: #ffd321; font-family: 'Teko', sans-serif; }
        .btn-cancel { background: #333; color: #fff; border:1px solid #555; padding:10px 20px; border-radius:5px; width:100%; cursor:pointer; margin-top: 10px; }

        /* TABLE */
        .history-section { margin: 0 10px; }
        .hist-header { background: linear-gradient(to right, #b8860b, #ffd700); padding: 8px 15px; border-radius: 5px 5px 0 0; color: #000; font-weight: bold; display:flex; justify-content:space-between; }
        .table-dark { width: 100%; font-size: 12px; background: rgba(0,0,0,0.8); color:#ccc; border-collapse: collapse; }
        .table-dark th { background: #222; color: #ffd321; padding: 10px; text-align:left; }
        .table-dark td { padding: 10px; border-bottom: 1px solid #333; }
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; text-transform: uppercase; }
        .bg-pending { background: #ffca28; color: #000; }
        .bg-success { background: #00c851; color: #fff; }
        .bg-batal { background: #ff4444; color: #fff; }

        footer { text-align: center; font-size: 11px; color: #666; margin-top: 30px; border-top: 1px solid #222; padding: 20px 0; background: #000; }
    </style>
</head>
<body>

    <?php include 'layout/header.php'; ?>
    
    <?php include 'layout/footer.php'; ?>
    

    <div class="header-saldo">
        <div><div class="user-label">ID MEMBER</div><div class="user-val"><?php echo $user['username']; ?></div></div>
        <div style="text-align:right;"><div class="user-label">SALDO AKTIF</div><div class="saldo-val">IDR <?php echo number_format($user['saldo'],0,',','.'); ?></div></div>
    </div>

    <main>
        
        <?php if($is_pending): ?>
            <div class="pending-lock">
                <i class="fa fa-hourglass-half fa-spin" style="font-size:40px; color:#ffca28; margin-bottom:15px;"></i>
                <h3 style="margin:0; color:#fff; font-size:16px;">PENARIKAN DIPROSES</h3>
                <div style="margin:20px 0;">
                    <span style="display:block; color:#aaa; font-size:12px;">Dana Akan Ditransfer:</span>
                    <span class="pending-amount">IDR <?php echo number_format($data_pending['jumlah']); ?></span>
                    <p style="color:#00c851; font-size:12px; margin-top:5px;">Estimasi: 3 Menit</p>
                </div>
                <form method="POST" onsubmit="return confirm('Batalkan? Saldo akan dikembalikan ke akun.');">
                    <?php input_csrf_token(); ?>
                    <input type="hidden" name="id_transaksi" value="<?php echo $data_pending['id']; ?>">
                    <button type="submit" name="batalkan_wd" class="btn-cancel">
                        <i class="fa fa-undo"></i> BATALKAN & REFUND SALDO
                    </button>
                </form>
            </div>

        <?php else: ?>
            
            <div class="form-card">
                <div class="info-bank-card">
                    <span class="bank-name"><?php echo $bank_user; ?></span>
                    <span class="rek-num"><?php echo $rek_user; ?></span>
                    <span class="acc-name">A/N <?php echo $an_user; ?></span>
                </div>

                <form method="POST" id="wdForm">
                    <?php input_csrf_token(); ?>
                    
                    <div class="form-row" style="border:none;">
                        <div class="label-col">Jumlah Tarik</div>
                        <div class="val-col">
                            <input type="tel" name="amount" id="amount" class="input-nominal" placeholder="Min Rp 50.000" onkeyup="formatRupiah(this)" required>
                        </div>
                    </div>

                    <div style="display:flex; gap:5px; margin-top:10px;">
                        <button type="button" onclick="setNominal(50000)" style="flex:1; padding:5px; background:#ccc; border:none; border-radius:4px;">50k</button>
                        <button type="button" onclick="setNominal(100000)" style="flex:1; padding:5px; background:#ccc; border:none; border-radius:4px;">100k</button>
                        <button type="button" onclick="setNominal(500000)" style="flex:1; padding:5px; background:#ccc; border:none; border-radius:4px;">500k</button>
                        <button type="button" onclick="setNominal(<?php echo $user['saldo']; ?>)" style="flex:1; padding:5px; background:#ffd321; border:none; border-radius:4px; font-weight:bold;">ALL</button>
                    </div>

                    <button type="submit" name="submit_withdraw" class="btn-submit">
                        <i class="fa fa-money-bill-wave"></i> CAIRKAN DANA
                    </button>
                </form>
            </div>
        <?php endif; ?>

        <div class="history-section">
            <div class="hist-header"><span>RIWAYAT TRANSAKSI</span><i class="fa fa-history"></i></div>
            <table class="table-dark">
                <thead><tr><th>Tgl</th><th>Ket</th><th>Jumlah</th><th>Status</th></tr></thead>
                <tbody>
                    <?php if(mysqli_num_rows($q_hist) > 0){
                        while($row = mysqli_fetch_assoc($q_hist)){ 
                            $st = $row['status'];
                            $cls = ($st=='sukses')?'bg-success':(($st=='batal')?'bg-batal':'bg-pending');
                            // Warna panah: Merah utk WD (Uang Keluar), Hijau utk Depo
                            $arrow = ($row['tipe_transaksi']=='keluar') ? '<i class="fa fa-arrow-up" style="color:#ff4444"></i>' : '<i class="fa fa-arrow-down" style="color:#00c851"></i>';
                            echo "<tr>
                                <td>".date('d/m', strtotime($row['tanggal']))."</td>
                                <td style='font-size:10px'>$arrow ".htmlspecialchars($row['keterangan'])."</td>
                                <td style='font-weight:bold; color:#fff;'>".number_format($row['jumlah'])."</td>
                                <td><span class='badge $cls'>".strtoupper($st)."</span></td>
                            </tr>";
                        }
                    } else { echo "<tr><td colspan='4' align='center'>Belum ada transaksi</td></tr>"; } ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>&copy; 2025 WINSORTOTO.</footer>

    <script>
        function formatRupiah(el) {
            let angka = el.value.replace(/\./g, '');
            if (!/^\d+$/.test(angka)) { el.value = angka.substring(0, angka.length - 1); return; }
            el.value = new Intl.NumberFormat('id-ID').format(angka);
        }
        function setNominal(amount) {
            document.getElementById('amount').value = new Intl.NumberFormat('id-ID').format(amount);
        }

        // SWEETALERT
        <?php if($alert_type != ""): ?>
            Swal.fire({
                icon: '<?php echo $alert_type; ?>',
                title: '<?php echo ($alert_type == "success") ? "BERHASIL!" : "PERHATIAN!"; ?>',
                text: '<?php echo $alert_message; ?>',
                background: '#fff',
                confirmButtonColor: '#000',
                confirmButtonText: 'OK'
            }).then((result) => {
                <?php if($alert_type == "success"): ?>
                    window.location.href = 'withdraw.php';
                <?php endif; ?>
            });
        <?php endif; ?>
    </script>
</body>
</html>
