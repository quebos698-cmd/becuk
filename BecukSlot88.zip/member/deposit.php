<?php
session_start();
include '../config/database.php';
include '../config/security_helper.php';

// 1. Cek Login
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'member'){
    header("location:login.php");
    exit;
}

$id_member = $_SESSION['user_id'];
$username_member = $_SESSION['username'];

// 2. Ambil Data User
$stmt = $koneksi->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id_member);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// 3. Auto Cancel (15 Menit)
mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status = 'batal', keterangan = CONCAT(keterangan, ' (Expired)') WHERE user_id='$id_member' AND status='pending' AND tanggal < (NOW() - INTERVAL 15 MINUTE)");

// 4. Cek Pending Lock
$cek_pending = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_member' AND tipe_transaksi='masuk' AND status='pending' ORDER BY id DESC LIMIT 1");
$data_pending = mysqli_fetch_assoc($cek_pending);
$is_pending = ($data_pending != null);

// Variabel untuk SweetAlert
$alert_type = ""; 
$alert_message = "";

// 5. PROSES SUBMIT
if(isset($_POST['submit_deposit'])){
    cek_csrf();
    
    if($is_pending) {
        $alert_type = "error";
        $alert_message = "Anda masih memiliki deposit pending!";
    } else {
        $metode = $_POST['payment_method'];
        
        // Ambil nominal FINAL (yang sudah ada kode unik untuk QRIS)
        // Di form nanti kita pakai input hidden untuk nilai asli yang dikirim
        $nominal_final = (int)str_replace('.', '', $_POST['amount_final']); 
        
        if($metode == 'QRIS'){
            $bank_detail = "QRIS (Kode Unik)";
        } else {
            $bank_detail = $_POST['bank_tujuan_val'];
        }

        $keterangan = "Deposit via " . $bank_detail;

        if($nominal_final < 10000){
            $alert_type = "warning";
            $alert_message = "Minimal Deposit Rp 10.000!";
        } else {
            $stmt = $koneksi->prepare("INSERT INTO riwayat_transaksi (user_id, tipe_transaksi, jumlah, keterangan, status, tanggal) VALUES (?, 'masuk', ?, ?, 'pending', NOW())");
            $stmt->bind_param("ids", $id_member, $nominal_final, $keterangan);
            
            if($stmt->execute()){
                // SUKSES - TAMPILKAN NOTIFIKASI PROFESIONAL
                $alert_type = "success";
                $alert_message = "Permintaan Deposit Berhasil!\\nSaldo akan diproses otomatis, pastikan nomor rekening dan nominal transfer BENAR.";
            } else {
                $alert_type = "error";
                $alert_message = "Gagal menyimpan data.";
            }
        }
    }
}

// Batal Manual
if(isset($_POST['batalkan_manual'])){
    cek_csrf();
    $id_trx = $_POST['id_transaksi'];
    mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status = 'batal', keterangan = CONCAT(keterangan, ' (User Cancel)') WHERE id = '$id_trx' AND user_id = '$id_member'");
    header("Refresh:0");
}

// History
$q_hist = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_member' ORDER BY id DESC LIMIT 5");
?>

    <?php include '../member/layout/footer.php'; ?>
    

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Deposit - WINSORTOTO</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Teko:wght@400;600&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body {
            background-color: #050505;
            background-image: url("https://myimagehost.me/assets/bg-m-winsor-natal.jpg");
            background-size: 100%; background-attachment: fixed;
            color: #fff; font-family: 'Roboto', sans-serif;
            margin: 0; padding: 0; padding-top: 110px; padding-bottom: 80px;
        }
        * { box-sizing: border-box; outline: none; -webkit-tap-highlight-color: transparent; }

        /* HEADER & TABS (SAMA SEPERTI SEBELUMNYA) */
        .header-saldo {
            background: linear-gradient(135deg, #1c1c1c 0%, #000 100%);
            border-top: 2px solid #ffd321; border-bottom: 2px solid #ffd321;
            padding: 10px 15px; margin: 0 5px 15px 5px; border-radius: 0 0 15px 15px;
            display: flex; justify-content: space-between; align-items: center;
        }
        .user-label { font-size: 12px; color: #aaa; }
        .user-val { color: #ffd321; font-weight: bold; text-transform: uppercase; }
        .saldo-val { font-family: 'Teko', sans-serif; font-size: 22px; font-weight: 600; color: #fff; }

        .method-tabs { display: flex; gap: 10px; margin: 0 10px 20px 10px; }
        .tab-btn {
            flex: 1; padding: 12px; background: #222; border: 1px solid #444; color: #aaa;
            text-align: center; border-radius: 8px; font-weight: bold; cursor: pointer; transition: all 0.3s;
        }
        .tab-btn.active {
            background: linear-gradient(to bottom, #d4af37, #b8860b);
            color: #000; border-color: #ffd700; box-shadow: 0 0 10px rgba(212, 175, 55, 0.3);
        }

        /* FORM STYLE */
        .form-card {
            background: #e5e5e5; color: #000; border-radius: 10px;
            margin: 0 10px 20px 10px; padding: 15px; border: 1px solid #fff;
        }
        .form-row { display: flex; align-items: center; padding: 10px 0; border-bottom: 1px solid #ccc; }
        .label-col { width: 35%; font-weight: bold; color: #444; font-size: 13px; }
        .val-col { width: 65%; font-weight: bold; color: #000; font-size: 14px; position: relative;}
        .custom-select, .input-nominal { width: 100%; padding: 8px; border: 1px solid #999; border-radius: 5px; font-weight: bold; font-size: 14px; }

        /* QRIS SECTION (PROFESIONAL) */
        .qris-section { display: none; text-align: center; }
        .qris-card {
            background: #fff; padding: 15px; border-radius: 10px; 
            border: 2px solid #000; display: inline-block; margin-bottom: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .qris-card img { width: 100%; max-width: 220px; }
        
        .total-payment-box {
            background: #000; color: #ffd321; padding: 15px; border-radius: 8px;
            margin-top: 10px; text-align: center; border: 2px solid #ffd321;
        }
        .total-label { font-size: 12px; color: #fff; display: block; margin-bottom: 5px; }
        .total-amount { font-family: 'Teko', sans-serif; font-size: 32px; font-weight: bold; letter-spacing: 2px; line-height: 1; }
        .kode-unik-info { color: #00c851; font-size: 11px; margin-top: 5px; font-style: italic; }

        /* TOMBOL */
        .btn-submit {
            width: 100%; padding: 15px; background: #047857; color: #fff;
            border: none; border-radius: 8px; font-weight: bold; font-size: 16px;
            cursor: pointer; margin-top: 15px; text-transform: uppercase;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2); transition: all 0.2s;
        }
        .btn-submit:active { transform: scale(0.98); }

        /* PENDING LOCK */
        .pending-lock {
            background: linear-gradient(to right, #1a1a1a, #000);
            border: 1px solid #ffca28; border-radius: 10px;
            padding: 30px 20px; text-align: center; margin: 20px 10px;
        }
        .pending-amount { font-size: 36px; color: #ffd321; font-family: 'Teko', sans-serif; }
        .btn-cancel { background: #d32f2f; color: #fff; border:none; padding:10px 20px; border-radius:5px; width:100%; cursor:pointer; }

        /* TABLE */
        .history-section { margin: 0 10px; }
        .hist-header { background: linear-gradient(to right, #b8860b, #ffd700); padding: 8px 15px; border-radius: 5px 5px 0 0; color: #000; font-weight: bold; display:flex; justify-content:space-between; }
        .table-dark { width: 100%; font-size: 12px; background: rgba(0,0,0,0.8); color:#ccc; border-collapse: collapse; }
        .table-dark th { background: #222; color: #ffd321; padding: 10px; text-align:left; }
        .table-dark td { padding: 10px; border-bottom: 1px solid #333; }
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 10px; font-weight: bold; text-transform: uppercase; }
        .bg-pending { background: #ffca28; color: #000; }
        .bg-success { background: #00c851; color: #fff; }
        .bg-batal { background: #ff4444; color: #fff; }

        footer { text-align: center; font-size: 11px; color: #666; margin-top: 30px; border-top: 1px solid #222; padding: 20px 0; background: #000; }
    </style>
</head>
<body>

    <?php include 'layout/header.php'; ?>

    <div class="header-saldo">
        <div><div class="user-label">ID MEMBER</div><div class="user-val"><?php echo $user['username']; ?></div></div>
        <div style="text-align:right;"><div class="user-label">SALDO AKTIF</div><div class="saldo-val">IDR <?php echo number_format($user['saldo'],0,',','.'); ?></div></div>
    </div>

    <main>
        
        <?php if($is_pending): ?>
            <div class="pending-lock">
                <i class="fa fa-clock fa-spin" style="font-size:40px; color:#ffca28; margin-bottom:15px;"></i>
                <h3 style="margin:0; color:#fff; font-size:16px;">TRANSAKSI SEDANG DIPROSES</h3>
                <div style="margin:20px 0;">
                    <span style="display:block; color:#aaa; font-size:12px;">Total Tagihan:</span>
                    <span class="pending-amount">IDR <?php echo number_format($data_pending['jumlah']); ?></span>
                    <p style="color:#00c851; font-size:12px; margin-top:5px;"><?php echo $data_pending['keterangan']; ?></p>
                </div>
                <form method="POST" onsubmit="return confirm('Batalkan transaksi ini?');">
                    <?php input_csrf_token(); ?>
                    <input type="hidden" name="id_transaksi" value="<?php echo $data_pending['id']; ?>">
                    <button type="submit" name="batalkan_manual" class="btn-cancel">BATALKAN TRANSAKSI</button>
                </form>
            </div>

        <?php else: ?>
            <div class="method-tabs">
                <div class="tab-btn active" id="tab-bank" onclick="switchMethod('bank')"><i class="fa fa-university"></i> BANK TRANSFER</div>
                <div class="tab-btn" id="tab-qris" onclick="switchMethod('qris')"><i class="fa fa-qrcode"></i> QRIS INSTANT</div>
            </div>

            <div class="form-card">
                <form method="POST" id="depositForm">
                    <?php input_csrf_token(); ?>
                    <input type="hidden" name="payment_method" id="payment_method" value="BANK">
                    <input type="hidden" name="bank_tujuan_val" id="bank_tujuan_val">
                    
                    <input type="hidden" name="amount_final" id="amount_final">

                    <div id="view-bank">
                        <div class="form-row">
                            <div class="label-col">Pilih Bank</div>
                            <div class="val-col">
                                <select id="bankSelect" class="custom-select" onchange="updateBankInfo()">
                                    <option value="">-- Pilih --</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="label-col">Rekening</div>
                            <div class="val-col" id="disp_acc">-</div>
                        </div>
                        <div class="form-row"><div class="label-col">No. Rek</div><div class="val-col" style="color:#d32f2f;" id="disp_num">-</div></div>
                        
                        <div class="form-row" style="border:none; margin-top:10px;">
                            <div class="label-col">Nominal (IDR)</div>
                            <div class="val-col">
                                <input type="tel" id="input_bank" class="input-nominal" placeholder="Min 10.000" onkeyup="updateNominalBank(this)">
                            </div>
                        </div>
                        <div style="display:flex; gap:5px; margin-top:10px;">
                            <button type="button" onclick="setNominal(20000)" style="flex:1; padding:5px; background:#ccc; border:none; border-radius:4px;">20k</button>
                            <button type="button" onclick="setNominal(50000)" style="flex:1; padding:5px; background:#ccc; border:none; border-radius:4px;">50k</button>
                            <button type="button" onclick="setNominal(100000)" style="flex:1; padding:5px; background:#ccc; border:none; border-radius:4px;">100k</button>
                        </div>
                    </div>

                    <div id="view-qris" class="qris-section">
                        <div class="qris-card">
                            <img src="../assets/img/my_qris.jpg" alt="QRIS CODE">
                            <div style="font-size:10px; font-weight:bold; margin-top:5px;">SCAN DENGAN OVO/DANA/GOPAY/SHOPEE</div>
                        </div>
                        
                        <div class="form-row" style="background:#fff; padding:10px; border-radius:8px;">
                            <div class="label-col">Input Nominal</div>
                            <div class="val-col">
                                <input type="tel" id="input_qris" class="input-nominal" placeholder="Cth: 50.000" onkeyup="calculateUniqueCode(this)">
                            </div>
                        </div>

                        <div class="total-payment-box">
                            <span class="total-label">TOTAL YANG HARUS DIBAYAR</span>
                            <span class="total-amount" id="display_total_qris">Rp 0</span>
                            <div class="kode-unik-info"><i class="fa fa-check-circle"></i> Kode unik otomatis ditambahkan</div>
                        </div>
                    </div>

                    <button type="submit" name="submit_deposit" class="btn-submit"><i class="fa fa-paper-plane"></i> PROSES DEPOSIT</button>
                </form>
            </div>
        <?php endif; ?>

        <div class="history-section">
            <div class="hist-header"><span>RIWAYAT TRANSAKSI</span><i class="fa fa-history"></i></div>
            <table class="table-dark">
                <thead><tr><th>Tgl</th><th>Via</th><th>Total</th><th>Status</th></tr></thead>
                <tbody>
                    <?php if(mysqli_num_rows($q_hist) > 0){
                        while($row = mysqli_fetch_assoc($q_hist)){ 
                            $st = $row['status'];
                            $cls = ($st=='sukses')?'bg-success':(($st=='batal')?'bg-batal':'bg-pending');
                            echo "<tr>
                                <td>".date('d/m H:i', strtotime($row['tanggal']))."</td>
                                <td style='font-size:10px'>".htmlspecialchars($row['keterangan'])."</td>
                                <td style='font-weight:bold; color:#ffd321;'>".number_format($row['jumlah'])."</td>
                                <td><span class='badge $cls'>".strtoupper($st)."</span></td>
                            </tr>";
                        }
                    } else { echo "<tr><td colspan='4' align='center'>Belum ada data</td></tr>"; } ?>
                </tbody>
            </table>
        </div>
    </main>

    <footer>&copy; 2025 WINSORTOTO.</footer>

    <script>
        const banks = [
            { code: "BCA", name: "BCA", acc: "BANDAR WINSOR", num: "8820332199" },
            { code: "BNI", name: "BNI", acc: "BANDAR WINSOR", num: "1234567890" },
            { code: "DANA", name: "DANA", acc: "WINSOR PAY", num: "081234567890" }
        ];

        // 1. INIT
        const select = document.getElementById('bankSelect');
        if(select){
            banks.forEach(b => {
                let opt = document.createElement('option'); opt.value = b.code; opt.innerText = b.name; select.appendChild(opt);
            });
        }

        let currentMethod = 'BANK';
        let uniqueCode = 0;

        // 2. SWITCH METHOD
        function switchMethod(method) {
            document.getElementById('tab-bank').classList.remove('active');
            document.getElementById('tab-qris').classList.remove('active');
            document.getElementById('view-bank').style.display = 'none';
            document.getElementById('view-qris').style.display = 'none';
            
            document.getElementById('payment_method').value = (method === 'qris') ? 'QRIS' : 'BANK';
            currentMethod = (method === 'qris') ? 'QRIS' : 'BANK';

            if(method === 'bank') {
                document.getElementById('tab-bank').classList.add('active');
                document.getElementById('view-bank').style.display = 'block';
                // Reset QRIS input
                document.getElementById('input_qris').value = '';
                document.getElementById('display_total_qris').innerText = 'Rp 0';
            } else {
                document.getElementById('tab-qris').classList.add('active');
                document.getElementById('view-qris').style.display = 'block';
                // Generate Kode Unik Baru (100 - 999)
                uniqueCode = Math.floor(Math.random() * 899) + 100;
                // Reset Bank input
                document.getElementById('input_bank').value = '';
            }
        }

        // 3. LOGIC QRIS KODE UNIK
        function calculateUniqueCode(el) {
            let raw = el.value.replace(/\./g, '');
            if(raw === '') { 
                document.getElementById('display_total_qris').innerText = 'Rp 0';
                document.getElementById('amount_final').value = 0;
                return; 
            }
            
            formatRupiah(el); // Format tampilan input

            let nominal = parseInt(raw);
            let total = nominal + uniqueCode;

            // Tampilkan Total (Termasuk kode unik)
            document.getElementById('display_total_qris').innerText = 'Rp ' + new Intl.NumberFormat('id-ID').format(total);
            
            // Simpan nilai final ke input hidden untuk dikirim ke DB
            document.getElementById('amount_final').value = total;
        }

        // 4. LOGIC BANK BIASA
        function updateNominalBank(el) {
            let raw = el.value.replace(/\./g, '');
            formatRupiah(el);
            // Untuk bank, nilai final = nilai input (tanpa kode unik)
            document.getElementById('amount_final').value = raw;
        }

        function updateBankInfo() {
            const val = select.value;
            const data = banks.find(b => b.code === val);
            document.getElementById('bank_tujuan_val').value = val;
            if(data) {
                document.getElementById('disp_acc').innerText = data.acc;
                document.getElementById('disp_num').innerText = data.num;
            }
        }

        function formatRupiah(el) {
            let angka = el.value.replace(/\./g, '');
            if (!/^\d+$/.test(angka)) { el.value = angka.substring(0, angka.length - 1); return; }
            el.value = new Intl.NumberFormat('id-ID').format(angka);
        }

        function setNominal(amount) {
            let el = document.getElementById('input_bank');
            el.value = amount;
            updateNominalBank(el); // Trigger format & save
        }

        // 5. SWEETALERT NOTIFICATION
        <?php if($alert_type != ""): ?>
            Swal.fire({
                icon: '<?php echo $alert_type; ?>',
                title: '<?php echo ($alert_type == "success") ? "BERHASIL!" : "PERHATIAN!"; ?>',
                text: '<?php echo $alert_message; ?>',
                background: '#fff',
                confirmButtonColor: '#000',
                confirmButtonText: 'OK SIAP'
            }).then((result) => {
                // Jika sukses, reload agar pending lock aktif
                <?php if($alert_type == "success"): ?>
                    window.location.href = 'deposit.php';
                <?php endif; ?>
            });
        <?php endif; ?>
    </script>
</body>
</html>
