<?php
session_start();
include '../config/database.php';
include '../config/security_helper.php';

if(!isset($_SESSION['role']) || $_SESSION['role'] != 'member'){
    header("location:login.php");
    exit;
}

$id_member = $_SESSION['user_id'];
$stmt = $koneksi->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id_member);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Home | KINGHOKI88</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

   <style>
/* State Active / Hover */
.nav-item.active, .nav-item:active {
    color: #ffd700; /* Emas */
}

.nav-item.active .icon-box {
    transform: translateY(-2px);
    text-shadow: 0 0 10px rgba(255, 215, 0, 0.6);
}

/* Efek Tombol Dompet (Tengah) */
.special-gold {
    background: linear-gradient(135deg, #ffd700, #b8860b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-size: 24px !important;
    filter: drop-shadow(0 0 5px rgba(255, 215, 0, 0.3));
}

/* --- POPUP TRANSAKSI (HIDDEN DEFAULT) --- */
.transaksi-menu {
    position: fixed;
    bottom: 85px; /* Muncul di atas navbar */
    left: 50%; transform: translateX(-50%) scale(0.8);
    width: 200px;
    background: rgba(20, 20, 20, 0.95);
    border: 1px solid #ffd700;
    border-radius: 15px;
    padding: 10px;
    display: flex; flex-direction: column; gap: 8px;
    opacity: 0; pointer-events: none; /* Sembunyi */
    transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); /* Efek membal */
    z-index: 10000;
    box-shadow: 0 5px 25px rgba(0,0,0,0.8);
}

/* Panah kecil di bawah popup */
.transaksi-menu::after {
    content: ''; position: absolute;
    bottom: -8px; left: 50%; transform: translateX(-50%);
    border-width: 8px 8px 0; border-style: solid;
    border-color: #ffd700 transparent transparent transparent;
}

/* Saat Popup Muncul */
.transaksi-menu.show {
    opacity: 1; pointer-events: auto;
    bottom: 85px;
    transform: translateX(-50%) scale(1);
}

/* Pilihan Menu di dalam Popup */
.menu-pill {
    display: flex; align-items: center; justify-content: center; gap: 10px;
    padding: 12px; border-radius: 8px;
    text-decoration: none; font-weight: bold; font-size: 13px;
    transition: transform 0.1s;
}
.menu-pill:active { transform: scale(0.95); }

.menu-pill.deposit {
    background: linear-gradient(to right, #00b09b, #96c93d);
    color: #fff; text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}
.menu-pill.withdraw {
    background: linear-gradient(to right, #ff512f, #dd2476);
    color: #fff; text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}

/* Overlay Gelap */
#nav-overlay {
    position: fixed; top: 0; left: 0; width: 100%; height: 100%;
    background: rgba(0,0,0,0.6);
    z-index: 9998;
    opacity: 0; pointer-events: none;
    transition: opacity 0.3s;
}
#nav-overlay.show { opacity: 1; pointer-events: auto; }

        /* Base Styles */
        body {
            background-color: #000;
            background-image: url("https://myimagehost.me/assets/bg-m-winsor-natal.jpg");
            background-size: 100%;
            background-attachment: fixed;
            color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            margin: 0; padding: 0;
            padding-top: 110px; /* Header Space */
            padding-bottom: 70px; /* Footer Space */
        }
        * { box-sizing: border-box; outline: none; -webkit-tap-highlight-color: transparent; }
        a { text-decoration: none; color: inherit; }

        /* --- 1. SALDO COMPACT --- */
        .lobby-content-top {
            background: linear-gradient(to left bottom, #444444, #201f1f, #030303);
            border-bottom: 2px solid #ffd321; border-top: 2px solid #ffd321;
            border-radius: 0 0 16px 16px;
            padding: 10px 15px; margin: 0 5px 15px 5px;
            display: flex; justify-content: space-between; align-items: center;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.5);
        }
        
        .user-info-wrapper { display: flex; align-items: center; gap: 5px; font-size: 12px; color: #ccc; }
        .mb-lobby-username { font-weight: bold; color: #ffd321; font-size: 13px; text-transform: uppercase; margin: 0; }
        
        .mb-lobby-balance { text-align: right; }
        .mb-lobby-balance span.label { display: block; font-size: 9px; color: #aaa; margin-bottom: -2px; }
        .mb-lobby-balance-text { font-weight: bold; color: #fff; font-size: 15px; } 
        
        .btn-refresh-balance { 
            display: inline-block; margin-left: 5px; cursor: pointer; color: #00ff00; font-size: 12px; z-index: 10;
        }

        /* Menu Grid */
        .button-lobby-container {
            display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; padding: 0 5px; margin-bottom: 15px;
        }
        .button-filter-lobby {
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            min-height: 60px; padding: 8px; border-radius: 8px;
            text-transform: uppercase; letter-spacing: 0.5px; gap: 5px;
            background: linear-gradient(135deg, #2b2b2b, #2b2b2b);
            border: 1px solid #444; color: #fff; width: 100%; cursor: pointer;
            transition: all 0.2s;
        }
        .button-filter-lobby img { width: 25px; }
        .button-filter-lobby span { font-size: 10px; }
        .button-filter-lobby.active {
            background: linear-gradient(to right bottom, #ffd52d, #d19c16);
            color: #000; border: 1px solid #ffd321;
        }
        .button-filter-lobby.active img { filter: brightness(0); }

        /* Banner */
        .banner-promotion { padding: 0 5px; margin-bottom: 10px; }
        .owl-carousel .item img { width: 100%; border-radius: 5px; border: 1px solid #ffd321; }

        .slot-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 KOLOM */
            gap: 8px;
            padding: 5px;
        }

        .slot-card {
            background: rgba(0, 0, 0, 0.6); /* Hitam Transparan */
            backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
            border: 1px solid #ffd700; /* Emas */
            border-radius: 8px;
            height: 110px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.5);
            cursor: pointer;
            transition: all 0.2s;
            -webkit-tap-highlight-color: transparent;
        }

        .slot-card:active {
            transform: scale(0.95);
            border-color: #fff;
        }

        /* GAMBAR DARI SOURCE ASLI */
        .slot-img {
            width: 80%;
            height: 60px;
            object-fit: contain;
            z-index: 1;
            filter: drop-shadow(0 2px 3px rgba(0,0,0,0.8));
        }

        /* NAMA GAME */
        .slot-name {
            font-size: 9px;
            color: #fff;
            margin-top: 5px;
            font-weight: 800;
            text-transform: uppercase;
            text-shadow: 0 1px 2px #000;
            z-index: 1;
            text-align: center;
            line-height: 1.1;
        }

        /* OVERLAY TOMBOL MAIN */
        .play-overlay {
            position: absolute; top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.85);
            display: flex; justify-content: center; align-items: center;
            opacity: 0; pointer-events: none;
            transition: opacity 0.2s; z-index: 10;
        }

        .slot-card.active .play-overlay {
            opacity: 1; pointer-events: auto;
        }

        .btn-main {
            text-decoration: none;
            background: linear-gradient(to right, #c59b2f, #ffd11b);
            color: #000; font-weight: 900; font-size: 11px;
            padding: 6px 15px; border-radius: 20px;
            border: 1px solid #fff; transform: scale(0.5);
            transition: transform 0.2s; box-shadow: 0 0 10px #ffd700;
        }

        .slot-card.active .btn-main { transform: scale(1); }
   
        /* Game Sections */
        .game-section { display: none; margin-top: 10px; }
        .game-section.show { display: block; }
        
        /* Judul Kategori */
        .title-type {
        width: 100%;
        text-align: center;
        margin: 25px 0 15px 0;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
    }
        .title-type h3 {
        position: relative;
        display: inline-block;
        padding: 12px 40px;
        color: #ffd700; /* Warna Teks Emas */
        font-family: 'Teko', sans-serif; /* Font Keren */
        font-size: 22px;
        font-weight: bold;
        text-transform: uppercase;
        letter-spacing: 2px;
        background: #000; /* Background Hitam */
        border-radius: 10px;
        z-index: 1;
        overflow: hidden;
        
        /* Efek Menyala (Glow) di sekeliling */
        box-shadow: 0 0 20px rgba(255, 215, 0, 0.4);
        text-shadow: 0 0 5px #ffd700;
    }
    .title-type h3::before {
        content: '';
        position: absolute;
        top: -150%; left: -150%;
        width: 400%; height: 400%;
        background: conic-gradient(
            transparent, 
            transparent, 
            transparent, 
            #ffd700, /* Emas Gelap */
            #ffffff, /* Putih (Inti Petir) */
            #ffd700, /* Emas Gelap */
            transparent 40%
        );
        animation: lightning-spin 4s linear infinite; /* Petir Berputar */
        z-index: -2;
    }

    /* 2. Layer Penutup Tengah (Agar terlihat seperti Border) */
    .title-type h3::after {
        content: '';
        position: absolute;
        inset: 3px; /* Ketebalan Border Petir (3px) */
        background: linear-gradient(to bottom, #222, #000); /* Gradasi Background Dalam */
        border-radius: 8px;
        z-index: -1;
    }

    /* Keyframe Putaran Petir */
    @keyframes lightning-spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

        /* Togel Grid (Sudah 2 Kolom) */
        .game-wrapper { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; padding: 0 5px; }
        .game-lobby-content {
            background: linear-gradient(to right bottom, #4d4123, #3b2e0b, #291f05);
            border: 2px solid #ffd321; border-radius: 8px;
            display: block; position: relative; margin-bottom: 5px; overflow: hidden;
        }
        .effect7 { display: flex; justify-content: center; align-items: center; flex-direction: column; height: 110px; padding: 10px; }
        .game-title { color: #f5f5f5; font-weight: bold; font-size: 11px; margin-bottom: 5px; text-align: center; }
        .lobby-game-angka-keluar { color: #ffd700; font-size: 20px; font-weight: bold; text-align: center; display: block; width: 100%; text-shadow: 1px 1px 0 #000; }
        .game-lobby-bottom { margin-top: 5px; width: 100%; text-align: center; }
        .timer-game { background: #2cb100; color: #fff; font-weight: bold; font-size: 11px; padding: 3px 8px; border-radius: 8px; display: inline-block; border: 1px solid #ffd321; }
        .game-lobby-live { background: #e40505; color: #fff; padding: 3px 8px; border-radius: 8px; font-size: 11px; font-weight: bold; }

        /* Live Casino Grid */
        .casino-wrapper { display: flex; gap: 5px; padding: 0 5px; margin-top: 10px; }
        .idnlive, .pp-container { flex: 1; text-align: center; }
        .idnlive img, .pp-container img { width: 100%; border-radius: 5px; border: 1px solid #333; }
        .btn-lobby-live { background: #7db039; color: white; width: 100%; text-align: center; padding: 8px; border-radius: 5px; display: block; margin-top: 5px; font-size: 12px; font-weight: bold; }

        /* --- SLOT GRID (DIUBAH KE 2 KOLOM) --- */
        .slot-content { 
            display: grid; 
            grid-template-columns: repeat(2, 1fr); /* SEKARANG 2 KOLOM */
            gap: 8px; /* Jarak antar game diperbesar sedikit */
            padding: 0 5px; margin-top: 10px; 
        }
        .slot-content img { width: 100%; border-radius: 5px; border: 1px solid #333; transition: transform 0.1s; cursor: pointer; }
        .slot-content img:active { transform: scale(0.95); }

        /* Arcade Grid (Sudah 2 Kolom) */
        .arcade-content { display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; padding: 0 5px; margin-top: 10px; }
        .arcade-content-item { text-align: center; color: #fff; font-size: 12px; }
        .arcade-content-item img { width: 100%; border-radius: 5px; border: 1px solid #333; margin-bottom: 5px; }
        .btn-arcade { background: #7db039; color: #fff; padding: 5px 10px; border-radius: 4px; display: inline-block; margin-top: 5px; font-size: 11px; font-weight: bold; }

        /* Footer */
        footer { text-align: center; font-size: 11px; color: #666; margin-top: 30px; border-top: 1px solid #222; padding: 20px 0; background: #000; }
        
        /* Input Cari */
        .input-cari-wrapper { margin: 10px 5px; }
        .input-cari-wrapper input { width: 100%; padding: 10px; text-align: center; border-radius: 5px; border: 1px solid #ccc; background: #fff; color: #000; }
    </style>
</head>
<body>

    <?php include 'layout/header.php'; ?>

    <div class="lobby-content-top" onclick="window.location.href='deposit.php'">
        <div class="user-info-wrapper">
            <span>Selamat Datang,</span>
            <p class="mb-lobby-username"><?php echo htmlspecialchars($user['username']); ?></p>
        </div>
        <div class="mb-lobby-balance">
            <span class="label">DOMPET UTAMA</span>
            <span class="mb-lobby-balance-text">
                IDR <?php echo number_format($user['saldo'], 0, ',', '.'); ?>
                <i class="fa fa-refresh btn-refresh-balance" onclick="event.stopPropagation(); location.reload()"></i>
            </span>
        </div>
    </div>

    <main><!DOCTYPE html>
    <html lang="in">
    <head>
        <meta charset="UTF-8">
        <title>Judul halaman</title>
    </head>
    <body>
        
    </body>
    </html>
        <div class="button-lobby-container">
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category active" onclick="filterGame('semua', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/semua.svg"><span>Semua</span></button></div>
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category" onclick="filterGame('live', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/live.svg"><span>Casino</span></button></div>
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category" onclick="filterGame('togel', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/togel.svg"><span>Togel</span></button></div>
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category" onclick="filterGame('slot', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/slot.svg"><span>Slot</span></button></div>
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category" onclick="filterGame('elottery', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/elottery.svg"><span>E-Lottery</span></button></div>
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category" onclick="filterGame('arcade', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/arcade.svg"><span>Arcade</span></button></div>
            <div class="button-lobby-wrapper"><button class="button-filter-lobby btn-category" onclick="filterGame('poker', this)"><img src="https://gass.winsordermawan.xyz/assets/img/global/icons/navbar/v1/poker.svg"><span>Poker</span></button></div>
        </div>

        <div class="input-cari-wrapper show"> <input type="text" id="cari-game" placeholder="Cari Game..."> </div>

        <div class="banner-promotion">
            <div class="owl-carousel owl-theme">
                <div class="item"><img src="https://premicloud.net/banner/image/promotion/CategoryMobile.webp"></div>
                <div class="item"><img src="https://gass.winsordermawan.xyz/assets/img/global/banner/poker/banner-mobile.webp"></div>
                <div class="item"><img src="https://premicloud.net/banner/image/promotion/newgrandprixcategory.webp"></div>
            </div>
        </div>

        <div id="game-togel" class="game-section show">
            <div class="title-type"><h3>TOGEL 4D</h3></div>
            <div class="game-wrapper">
                <a href="https://gass.winsordermawan.xyz/games/minigame/TM5DMobile" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">5D TOTO MACAU</div><div class="lobby-game-angka-keluar">56893</div><div class="game-lobby-bottom"><span class="timer-game" data-close="15:00:00">LOADING...</span></div></div>
                </a>
                <a href="https://gass.winsordermawan.xyz/games/minigame/KK4DMobile" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">KING KONG 4D</div><div class="lobby-game-angka-keluar">1942</div><div class="game-lobby-bottom"><div class="game-lobby-live">BET CLOSED</div></div></div>
                </a>
                <a href="https://gass.winsordermawan.xyz/games/tm/m17" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">4D TOTO MACAU</div><div class="lobby-game-angka-keluar">9852</div><div class="game-lobby-bottom"><span class="timer-game" data-close="13:00:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">HONGKONG</div><div class="lobby-game-angka-keluar">1247</div><div class="game-lobby-bottom"><span class="timer-game" data-close="23:00:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">SINGAPORE</div><div class="lobby-game-angka-keluar">7055</div><div class="game-lobby-bottom"><span class="timer-game" data-close="17:45:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">SYDNEY</div><div class="lobby-game-angka-keluar">3125</div><div class="game-lobby-bottom"><span class="timer-game" data-close="13:50:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">CAMBODIA</div><div class="lobby-game-angka-keluar">4849</div><div class="game-lobby-bottom"><span class="timer-game" data-close="11:50:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">CHINA</div><div class="lobby-game-angka-keluar">1130</div><div class="game-lobby-bottom"><span class="timer-game" data-close="15:30:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">TAIWAN</div><div class="lobby-game-angka-keluar">1237</div><div class="game-lobby-bottom"><span class="timer-game" data-close="20:45:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">JAPAN</div><div class="lobby-game-angka-keluar">1109</div><div class="game-lobby-bottom"><span class="timer-game" data-close="17:20:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">PCSO</div><div class="lobby-game-angka-keluar">4929</div><div class="game-lobby-bottom"><span class="timer-game" data-close="20:00:00">LOADING...</span></div></div>
                </a>
                <a href="#" class="game-lobby-content">
                    <div class="effect7"><div class="game-title">BULLSEYE</div><div class="lobby-game-angka-keluar">5980</div><div class="game-lobby-bottom"><span class="timer-game" data-close="12:00:00">LOADING...</span></div></div>
                </a>
            </div>
        </div>

        <div id="game-live" class="game-section show" style="margin-top:20px;">
            <div class="title-type"><h3>LIVE CASINO</h3></div>
            <div class="casino-wrapper">
                <div class="idnlive">
                    <a href="https://gass.winsordermawan.xyz/games/minigame/bolagilaMobile"><img src="https://gass.winsordermawan.xyz/assets/img/wlb2c/casino_v2/banner/idnlive_mobile.webp"></a>
                    <a href="https://gass.winsordermawan.xyz/games/minigame/bolagilaMobile" class="btn-lobby-live">LOBBY</a>
                </div>
                <div class="pp-container">
                    <a href="https://gass.winsordermawan.xyz/games/minigame/101*ppldMobile"><img src="https://gass.winsordermawan.xyz/assets/img/wlb2c/casino_v2/banner/pp_mobile.webp"></a>
                    <a href="https://gass.winsordermawan.xyz/games/minigame/101*ppldMobile" class="btn-lobby-live">LOBBY</a>
                </div>
            </div>
        </div>

        <div id="game-slot" class="game-section show" style="margin-top:20px;">
            <div class="title-type"><h3>SLOT GAMES</h3></div>
<div id="game-slot" class="game-section show" style="margin-top: 20px; margin-bottom: 80px;">
    
    <div class="slot-grid">
        
        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-7.webp?v=20240813" class="slot-img">
            <span class="slot-name">PRAGMATIC</span>
            <div class="play-overlay"><a href="../games/slot/pragmat.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-9.webp?v=20240813" class="slot-img">
            <span class="slot-name">PG SOFT</span>
            <div class="play-overlay"><a href="../games/slot/pgsoft.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-16.webp?v=20240813" class="slot-img">
            <span class="slot-name">HABANERO</span>
            <div class="play-overlay"><a href="../games/slot/habanero.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-17.webp?v=20240813" class="slot-img">
            <span class="slot-name">MICROGAMING</span>
            <div class="play-overlay"><a href="../games/slot/microgaming.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-29.webp?v=20240813" class="slot-img">
            <span class="slot-name">SPADE GAMING</span>
            <div class="play-overlay"><a href="../games/slot/spadegaming.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-6.webp?v=20240813" class="slot-img">
            <span class="slot-name">JOKER</span>
            <div class="play-overlay"><a href="../games/slot/joker.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-92.webp?v=20240813" class="slot-img">
            <span class="slot-name">NO LIMIT CITY</span>
            <div class="play-overlay"><a href="../games/slot/nolimitcity.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-67.webp?v=20240813" class="slot-img">
            <span class="slot-name">TOP TREND</span>
            <div class="play-overlay"><a href="../games/slot/ttg.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-13.webp?v=20240813" class="slot-img">
            <span class="slot-name">CQ9 GAMING</span>
            <div class="play-overlay"><a href="../games/slot/cq9.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-65.webp?v=20240813" class="slot-img">
            <span class="slot-name">PLAYSTAR</span>
            <div class="play-overlay"><a href="../games/slot/playstar.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-93.webp?v=20240813" class="slot-img">
            <span class="slot-name">RED TIGER</span>
            <div class="play-overlay"><a href="../games/slot/redtiger.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-94.webp?v=20240813" class="slot-img">
            <span class="slot-name">NETENT</span>
            <div class="play-overlay"><a href="../games/slot/netent.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-18.webp?v=20240813" class="slot-img">
            <span class="slot-name">PLAY'N GO</span>
            <div class="play-overlay"><a href="../games/slot/playngo.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-42.webp?v=20240813" class="slot-img">
            <span class="slot-name">YGGDRASIL</span>
            <div class="play-overlay"><a href="../games/slot/yggdrasil.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-70.webp?v=20240813" class="slot-img">
            <span class="slot-name">JILI</span>
            <div class="play-overlay"><a href="../games/slot/jili.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-54.webp?v=20240813" class="slot-img">
            <span class="slot-name">ADVANT PLAY</span>
            <div class="play-overlay"><a href="../games/slot/advantplay.php" class="btn-main">MAIN</a></div>
        </div>

        <div class="slot-card" onclick="togglePlay(this)">
            <img src="//dsuown9evwz4y.cloudfront.net/Images/nexus-beta/menu/mobile/home-menu-3/game-code-90.webp?v=20240813" class="slot-img">
            <span class="slot-name">SKYWIND</span>
            <div class="play-overlay"><a href="../games/slot/skywind.php" class="btn-main">MAIN</a></div>
        </div>

    </div>


</div>

            </div>
        </div>

        <div id="game-elottery" class="game-section" style="display:none; margin-top:20px;">
            <div class="title-type"><h3>E-LOTTERY GAMES</h3></div>
            <div class="slot-content">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/HiRoller.webp" onclick="location.href='/games/minigame/davinci_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/games/slots/idnlottery/RouletteTrinity.webp" onclick="location.href='/games/minigame/roulette_trinity_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/Kampus6D.webp" onclick="location.href='/games/minigame/kampus6d_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/LongHuClash.webp" onclick="location.href='/games/minigame/long_hu_clash_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/sicbo6.webp" onclick="location.href='/games/minigame/sicbo6_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/SMP4D.webp" onclick="location.href='/games/minigame/smp4d_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/dragon5d.webp" onclick="location.href='/games/minigame/dragon5d_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/WinzoWheels9.webp" onclick="location.href='/games/minigame/wingo9_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/Bloodmoon.webp" onclick="location.href='/games/minigame/blood_moon_lotteryMobile'">
                <img src="https://premicloud.net/banner/image/assetgames/slots/idnlottery/Sicbo12.webp" onclick="location.href='/games/minigame/sicbo12_lotteryMobile'">
            </div>
        </div>

        <div id="game-arcade" class="game-section" style="display:none; margin-top:20px;">
            <div class="title-type"><h3>ARCADE GAMES</h3></div>
            <div class="arcade-content">
                <div class="arcade-content-item">
                    <img src="https://shareservice.net/banner/image/assetgames/idnrng/DoubleRoulette.webp">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/DBR00001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/CoinPusher.webp">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/CNP00001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/RFCpotrait.webp">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/RFC00001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/MinesweeperHolywood.webp">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/SHW00001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/PlinkBall.webp">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/PLB00001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/roulette.png">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/RL000001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/plinko.png">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/PLK00001/reel'">Play</div>
                </div>
                <div class="arcade-content-item">
                    <img src="https://premicloud.net/banner/image/assetgames/idnrng/ShogunEmpire.png">
                    <div class="btn-arcade" onclick="location.href='/arcade/launch/SHG00001/reel'">Play</div>
                </div>
            </div>
        </div>

        <div id="game-poker" class="game-section" style="display:none; margin-top:20px;">
            <div class="title-type"><h3>POKER GAMES</h3></div>
            <div class="slot-content">
                <img src="https://gass.winsordermawan.xyz/assets/img/global/idnpoker/JOC.webp" onclick="location.href='/game/launch?game_category=poker&gameid=ip_joc'">
                <img src="https://gass.winsordermawan.xyz/assets/img/global/idnpoker/GPL.webp" onclick="location.href='/game/launch?game_category=poker&gameid=ip_gpl'">
                <img src="https://gass.winsordermawan.xyz/assets/img/global/idnpoker/JOS.webp" onclick="location.href='/game/launch?game_category=poker&gameid=ip_jos'">
            </div>
        </div>

    </main>

    <footer>
        <p>&copy; 2025 WINSORTOTO. All Rights Reserved.</p>
    </footer>

   <?php 
// =================================================================
// SMART INCLUDE FOOTER (KHUSUS MEMBER/LOBBY.PHP)
// =================================================================
// Karena file ini ada di folder 'member', kita cukup mundur 1 langkah (../)
// untuk ke folder 'layout'.

$footer_paths = [
    '../layout/footer.php',       // Prioritas 1: Mundur 1 folder (member -> root -> layout)
    '../../layout/footer.php',    // Prioritas 2: Mundur 2 folder (Jaga-jaga)
    'layout/footer.php'           // Prioritas 3: Satu folder (Jaga-jaga)
];

$footer_found = false;
foreach ($footer_paths as $path) {
    if (file_exists($path)) {
        include $path;
        $footer_found = true;
        break;
    }
}

if (!$footer_found) {
    echo "";
}
?>
    

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        $('.owl-carousel').owlCarousel({ loop:true, margin:10, nav:false, autoplay:true, items:1 });

        function filterGame(cat, el) {
            $('.button-filter-lobby').removeClass('active');
            $(el).addClass('active');
            
            $('.game-section').hide();
            
            if(cat === 'semua') {
                $('#game-togel, #game-live, #game-slot').fadeIn();
            } else {
                $('#game-' + cat).fadeIn();
            }
        }

        // Timer Togel Logic
        function updateTimers() {
            const now = new Date();
            const timers = document.querySelectorAll('.timer-game');
            
            timers.forEach(el => {
                const closeTime = el.getAttribute('data-close').split(':');
                let target = new Date();
                target.setHours(closeTime[0], closeTime[1], 0);
                
                let diff = Math.floor((target - now) / 1000);
                if(diff < 0) diff += 86400; // Reset ke besok

                let h = Math.floor(diff / 3600);
                let m = Math.floor((diff % 3600) / 60);
                let s = diff % 60;
                
                el.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
                
                if(diff < 3600) el.style.backgroundColor = "#e40505";
                else el.style.backgroundColor = "#2cb100";
            });
        }
        setInterval(updateTimers, 1000);
        updateTimers();
    </script>
    <script>
        function togglePlay(element) {
            document.querySelectorAll('.slot-card').forEach(function(card) {
                if (card !== element) {
                    card.classList.remove('active');
                }
            });
            element.classList.toggle('active');
        }
    </script>
</body>
</html>
