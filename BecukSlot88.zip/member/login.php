<?php
session_start();
include '../config/database.php';
include '../config/security_helper.php';

// Redirect jika sudah login
if(isset($_SESSION['role'])){
    if($_SESSION['role'] == 'admin') header("location:../admin/dashboard.php");
    else header("location:lobby.php");
    exit;
}

$error_msg = "";
if(isset($_POST['login'])){
    cek_csrf();
    $username = bersihkan_input($_POST['entered_login']);
    $password = $_POST['entered_password'];

    $stmt = $koneksi->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $data = $result->fetch_assoc();
        if(password_verify($password, $data['password'])){
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['username'] = $data['username'];
            $_SESSION['role'] = $data['role'];
            if($data['role'] == 'admin') header("location:../admin/dashboard.php");
            else header("location:lobby.php");
            exit;
        } else { $error_msg = "Password Salah!"; }
    } else { $error_msg = "Username tidak ditemukan!"; }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>KINGHOKI88 ~ Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">

    <style>
        /* BASE STYLE */
        body { background-color: #000; margin: 0; padding: 0; font-family: sans-serif; color: #fff; background-image: url(https://myimagehost.me/assets/bg-m-winsor-natal.jpg); background-size: 100%; background-attachment: fixed; padding-top: 100px; }
        a { text-decoration: none; color: inherit; }
        * { box-sizing: border-box; outline: none; }

        /* CONTENT */
        .container { padding: 0 10px; padding-bottom: 60px; }
        .owl-carousel .item img { width: 100%; border-radius: 5px; border: 1px solid #ffd321; }

        /* MENU DI BAWAH BANNER */
        .list-menu-mobile { width: 100%; margin-top: 10px; display: flex; justify-content: center; gap: 5px; margin-bottom: 15px; }
        .list-menu-mobile a { width: 20%; display: inline-block; }
        .list-menu-mobile a img { width: 100%; }

        /* FORM LOGIN TRANSPARAN */
        .wrapper2 { margin-top: 5px; text-align: center; }
        .note { color: #ffd321; font-size: 12px; margin-bottom: 5px; font-weight: bold; }
        .login-wrapper { background: none !important; border: none !important; padding: 0 !important; }
        .form-group { margin-bottom: 10px; }
        .contactField { width: 100%; padding: 12px; border-radius: 10px; border: 2px solid #f8c51e; background: #fff; color: #000; text-align: center; font-size: 14px; font-weight: bold; }
        
        /* BUTTONS */
        .buttonjoin { margin-top: 10px; }
        .buttonWrap { width: 100%; display: block; padding: 12px; border-radius: 14px; font-weight: bold; text-transform: uppercase; border: 2px solid #ffd321; color: #000; font-size: 14px; }
        .button-blue { background: linear-gradient(120deg, #d19c16, #e7b537, #ffd11b, #ffd52d); background-size: 200% 100%; animation: shine 3s infinite linear; }
        .buttong { background: linear-gradient(to bottom, #ffa800, #ffbb00 , #ffd000, #ffee00); }
        @keyframes shine { 0% { background-position: 100% 0; } 100% { background-position: -100% 0; } }

        /* JACKPOT */
        .bungkus-jackpot { margin-top: 20px; }
        .progresif-jackpot { font-size: 19px; font-weight: 800; border-radius: 5px; text-align: center; color: #ffd000; background: url(https://i.gyazo.com/84900b28a0eb5d33a9b652ba2b96b1ce.gif) center no-repeat; background-size: 100%; height: 60px; width: 100%; display: flex; align-items: center; justify-content: center; text-shadow: 2px 2px 2px #000; }
        .progresif-jackpot span { color: white; margin-right: 10px; font-size: 14px; }

        /* SLIDER GAME (BANYAK GAMBAR) */
        .slider-game { margin-top: 20px; }
        .slider-game div { padding: 0 4px; outline: none; }
        .slider-game img { width: 100%; border-radius: 8px; border: 2px solid #ffd321; transition: transform 0.3s; }
        
        /* STATUS BANK (LENGKAP) */
        .bank-status { display: flex; flex-wrap: wrap; justify-content: space-between; gap: 5px; margin-top: 20px; }
        .bank { width: 48%; border: 2px solid #ffd321; border-radius: 8px; background: #000; padding: 5px; display: flex; align-items: center; justify-content: space-between; margin-bottom: 5px; }
        .bank img.logo { height: 25px; max-width: 80px; object-fit: contain; }
        .bank img.dot { height: 10px; }

        /* FAKE WD SNACKBAR */
        #snackbar-mobile { visibility: hidden; width: 95%; background: linear-gradient(to right, #d4af37, #f7ef8a, #d4af37); color: #000; text-align: center; border-radius: 50px; position: fixed; z-index: 9999; border: 2px solid #fff; display: flex; align-items: center; height: 50px; left: 2.5%; bottom: 20px; padding: 0 10px; box-shadow: 0 0 15px #ffd321; }
        #snackbar-mobile.tampil { visibility: visible; animation: slideUp 0.5s ease-out; }
        @keyframes slideUp { from {bottom: -100px; opacity: 0;} to {bottom: 20px; opacity: 1;} }
        .wd-icon { width: 35px; height: 35px; background: #000; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 10px; border: 1px solid #ffd321; }
        .wd-text { font-size: 12px; text-align: left; line-height: 1.3; font-weight: bold; }
        .wd-amount { color: #006400; font-weight: 900; font-size: 13px; }

        footer { text-align: center; color: #888; font-size: 11px; margin-top: 20px; border-top: 1px solid #333; padding-top: 10px; }
        .alert-error { background: #d32f2f; color: white; padding: 10px; margin-bottom: 10px; border-radius: 5px; font-size: 12px; font-weight: bold; }
        .links-area { margin: 10px 0; font-size: 12px; }
        .links-area a { color: #fff; text-decoration: underline; margin: 0 5px; }
    </style>
</head>
<body>

    <?php include 'layout/header.php'; ?>

    <div class="container">
        
        <div class="owl-carousel owl-theme" style="margin-top:10px;">
            <div class="item"><img src="https://myimagehost.me/winsortoto/winsorpromo.jpg"></div>
            <div class="item"><img src="https://myimagehost.me/winsortoto/qriswinsortoto.jpg"></div>
            <div class="item"><img src="https://myimagehost.me/winsortoto/togelwinsor.jpg"></div>
        </div>

        <div class="list-menu-mobile">
            <a href="#"><img src="https://myimagehost.me/winsortoto/1.webp"></a>
            <a href="#"><img src="https://myimagehost.me/winsortoto/2.webp"></a>
            <a href="#"><img src="https://myimagehost.me/winsortoto/3.webp"></a>
            <a href="#"><img src="https://myimagehost.me/winsortoto/4.webp"></a>
        </div>

        <div class="wrapper2">
            <div class="note center">Silahkan login untuk mulai bermain</div>
            
            <?php if($error_msg != ""): ?>
                <div class="alert-error"><?php echo $error_msg; ?></div>
            <?php endif; ?>

            <div class="login-wrapper">
                <form method="POST">
                    <?php input_csrf_token(); ?>
                    
                    <div class="form-group">
                        <input name="entered_login" class="contactField" type="text" placeholder="Username" required autocomplete="off">
                    </div>
                    <div class="form-group">
                        <input name="entered_password" class="contactField" type="password" placeholder="Password" required>
                    </div>

                    <div class="links-area">
                        <a href="#">Lite Mode</a> | <a href="#">Lupa Password?</a>
                    </div>

                    <div class="buttonjoin">
                        <button type="submit" name="login" class="buttonWrap button-blue">LOG IN</button>
                    </div>
                </form>

                <div class="buttonjoin">
                    <a href="register.php" class="buttonWrap buttong">DAFTAR</a>
                </div>
                <div class="buttonjoin">
                    <a href="#" class="buttonWrap button-blue">PROMOSI</a>
                </div>
            </div>
        </div>

        <div class="bungkus-jackpot">
            <div class="progresif-jackpot">
                <span>IDR</span> <div id="jackpot-counter">1.131.665.972</div>
            </div>
        </div>

        <div class="slider-game">
            <div><img src="https://i.gyazo.com/90220df7958039fe8da325251a9bb52a.png"></div>
            <div><img src="https://i.gyazo.com/a7abddc531bfdea9db78885065686c80.png"></div>
            <div><img src="https://i.gyazo.com/cd03bfc05ee6caab738a0291c9d8c311.png"></div>
            <div><img src="https://i.gyazo.com/ea1e4fad3bfd21368a186d06647251cb.png"></div>
            <div><img src="https://i.gyazo.com/6919102ba94123f12b23d9bd012f1195.png"></div>
            <div><img src="https://i.gyazo.com/9e4a16185cc29dd41759c4e330f29552.png"></div>
            <div><img src="https://i.gyazo.com/eb503d81d53c0461e2d7209f1b00a6e5.png"></div>
            <div><img src="https://i.gyazo.com/13b933d2f88882eb0cbd3cae7f0ddbc2.png"></div>
            <div><img src="https://i.gyazo.com/e614c8dee57e7030846b291c62e3d315.png"></div>
            <div><img src="https://i.gyazo.com/8760ad08841a9bc50bffed6931c76d48.png"></div>
        </div>

        <div class="bank-status">
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/wz7Qwx1/bca.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/zPVSDvX/bni.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/59FQqyK/bri.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/0rc76zn/mandiri.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/4MtDDs8/ovo.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/5YWdV2d/gopay.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/fn2W1sj/dana.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/n07rTDS/link.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/FBxjwh2/bsi.gif" class="logo"></div>
            <div class="bank"><img src="/img//green-dot.gif" class="dot"><img src="https://i.ibb.co/LPbfvwf/bsi.gif" class="logo"></div> </div>

    </div>

    <footer>
        &copy; Copyright 2025 KINGHOKI88. All Rights Reserved.
    </footer>

    <div id="snackbar-mobile">
        <div class="wd-icon">
            <i class="fa fa-check" style="color:#ffd321;"></i>
        </div>
        <div id="withdraw-content" class="wd-text"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>

    <script>
        $('.owl-carousel').owlCarousel({ loop:true, margin:10, nav:false, autoplay:true, items:1 });
        $('.slider-game').slick({ slidesToShow: 3, slidesToScroll: 1, autoplay: true, autoplaySpeed: 1500, arrows: false, dots: false });</script>
       
<script type="text/javascript">
(function(_0x4e2d, _0x5f9a) {
    var _0x5b3c = function(_0x2d8f) {
        while (--_0x2d8f) {
            _0x4e2d['push'](_0x4e2d['shift']());
        }
    };
    _0x5b3c(++_0x5f9a);
}(['bG9n', 'aW5uZXJUZXh0', 'Z2V0RWxlbWVudEJ5SWQ=', 'amFja3BvdC1jb3VudGVy', 'dG9Mb2NhbGVTdHJpbmc=', 'cmVwbGFjZQ==', 'aWQtSUQ=', 'bWF0Y2g=', 'aW5jbHVkZXM=', 'aHRtbA==', 'I3dpdGhkcmF3LWNvbnRlbnQ=', 'YWRkQ2xhc3M=', 'dGFtcGls', 'I3NuYWNrYmFyLW1vYmlsZQ==', 'cmVtb3ZlQ2xhc3M=', 'c2V0VGltZW91dA==', 'QWRpdCxBZ3VuZyxBaG1hZCxBa2JhcixBbGRpLEFuZHJlLEFuZ2dhLEFud2FyLEFyaWYsQXNlcCxCYWdhcyxCYW1iYW5nLEJheXUsQmVuaSxCaW1hLEJveSxDYWh5byxDYW5kcmEsRGFuaSxEZWRpLERlbmksRGlraSxDaW1hcyxEb25pLEVrYSxGYWlzYWwsRmFyaWQsRmVycnksR2FsaWgsR2lsYW5nLEd1bmF3YW4sR3VudHVyLEhhZGksSGVuZHJhLEhlcmksSWJyYSxJa2hzYW4sSWxoYW0sSW5kcmEsSXJmYW4sSXdhbixKYWthLEphbWFsLEplZnJpLEpva28sS2V2aW4sS2lraSxLcmlzbmEsS3VybmlhLEx1a21hbixNYXVsYW5hLE1pa28sTXVoYW1hZCxOYW5kYSxOdWdyb2hvLE51cixPa2ksUGFuZHUsUHJhdGFtYSxQdXRyYSxSYWhtYXQsUmFtYSxSYW5keSxSZXphLFJpYW4sUmlraSxSaXpreSxSb25pLFJvc2lkLFJ5YW4sU2FuZGksU2FwdXRyYSxTYXRyaWEsU2V0aWF3YW4sU2xhbWV0LFNvbmksU3VsdGFuLFN1cnlhLFRhdWZpayxUZWdhcixUaW8sVG9tbXksVHJpLFVqYW5nLFdhaHl1LFdhd2FuLFdpYm93byxXaWxseSxXaXNudSxZYW50byxZb2dhLFlvc2VwLFl1ZGEsWXVkaSxZdXN1ZixaYWluYWwsWmFraSxBeXUsQmVsbGEsQ2luZHksRGV3aSxEaWFuLEVrYSxGaXRyaSxHaXRhLEhhbmEsSW5kYWgsSW50YW4sSnVsaWEsS2FydGlrYSxMaWEsTGlzYSxNYXlhLE1lZ2EsTmFkaWEsTmluYSxOb3ZpLE51cnVsLFB1dHJpLFJpbmEsUmluaSxTYXJpLFNpc2thLFNpdGksU3JpLFN1Y2ksVGFyaSxUaW5hLFZpbmEsV3VsYW4sWWFuaSxZdWxpYSxBZG1pbixCYW5kYXIsQm9zLENhcHRhaW4sQ3VhbixEZXdhLERyYWdvbixFYWdsZSxHYWNvcixIb2tpLEh1bnRlcixKYWNrcG90LEphZ3VhcixKdXJhZ2FuLEtpbmcsTGlvbixMb3JkLEx1Y2t5LE1hbixNYXN0ZXI=', 'ODgsOTksNzc3LG5kLGRvbSxwaSxkaSxnYWNvcixrYSxocyxzbyx0eSxuZSxudSxrbyxwbyxkLGEsZyx0LHYsZCxjLGU=', 'c3BsaXQ=', 'bWFw', 'SURSIC', 'IFRlbGFoIFdpdGhkcmF3PGJyPjxzcGFuIGNsYXNzPSJ3ZC1hbW91bnQiPg==', 'PC9zcGFuPg=='], 0x1e3));

var _0x2a1b = function(_0x4e2d, _0x5f9a) {
    _0x4e2d = _0x4e2d - 0x0;
    var _0x5b3c = ['bG9n', 'aW5uZXJUZXh0', 'Z2V0RWxlbWVudEJ5SWQ=', 'amFja3BvdC1jb3VudGVy', 'dG9Mb2NhbGVTdHJpbmc=', 'cmVwbGFjZQ==', 'aWQtSUQ=', 'bWF0Y2g=', 'aW5jbHVkZXM=', 'aHRtbA==', 'I3dpdGhkcmF3LWNvbnRlbnQ=', 'YWRkQ2xhc3M=', 'dGFtcGls', 'I3NuYWNrYmFyLW1vYmlsZQ==', 'cmVtb3ZlQ2xhc3M=', 'c2V0VGltZW91dA==', 'QWRpdCxBZ3VuZyxBaG1hZCxBa2JhcixBbGRpLEFuZHJlLEFuZ2dhLEFud2FyLEFyaWYsQXNlcCxCYWdhcyxCYW1iYW5nLEJheXUsQmVuaSxCaW1hLEJveSxDYWh5byxDYW5kcmEsRGFuaSxEZWRpLERlbmksRGlraSxDaW1hcyxEb25pLEVrYSxGYWlzYWwsRmFyaWQsRmVycnksR2FsaWgsR2lsYW5nLEd1bmF3YW4sR3VudHVyLEhhZGksSGVuZHJhLEhlcmksSWJyYSxJa2hzYW4sSWxoYW0sSW5kcmEsSXJmYW4sSXdhbixKYWthLEphbWFsLEplZnJpLEpva28sS2V2aW4sS2lraSxLcmlzbmEsS3VybmlhLEx1a21hbixNYXVsYW5hLE1pa28sTXVoYW1hZCxOYW5kYSxOdWdyb2hvLE51cixPa2ksUGFuZHUsUHJhdGFtYSxQdXRyYSxSYWhtYXQsUmFtYSxSYW5keSxSZXphLFJpYW4sUmlraSxSaXpreSxSb25pLFJvc2lkLFJ5YW4sU2FuZGksU2FwdXRyYSxTYXRyaWEsU2V0aWF3YW4sU2xhbWV0LFNvbmksU3VsdGFuLFN1cnlhLFRhdWZpayxUZWdhcixUaW8sVG9tbXksVHJpLFVqYW5nLFdhaHl1LFdhd2FuLFdpYm93byxXaWxseSxXaXNudSxZYW50byxZb2dhLFlvc2VwLFl1ZGEsWXVkaSxZdXN1ZixaYWluYWwsWmFraSxBeXUsQmVsbGEsQ2luZHksRGV3aSxEaWFuLEVrYSxGaXRyaSxHaXRhLEhhbmEsSW5kYWgsSW50YW4sSnVsaWEsS2FydGlrYSxMaWEsTGlzYSxNYXlhLE1lZ2EsTmFkaWEsTmluYSxOb3ZpLE51cnVsLFB1dHJpLFJpbmEsUmluaSxTYXJpLFNpc2thLFNpdGksU3JpLFN1Y2ksVGFyaSxUaW5hLFZpbmEsV3VsYW4sWWFuaSxZdWxpYSxBZG1pbixCYW5kYXIsQm9zLENhcHRhaW4sQ3VhbixEZXdhLERyYWdvbixFYWdsZSxHYWNvcixIb2tpLEh1bnRlcixKYWNrcG90LEphZ3VhcixKdXJhZ2FuLEtpbmcsTGlvbixMb3JkLEx1Y2t5LE1hbixNYXN0ZXI=', 'ODgsOTksNzc3LG5kLGRvbSxwaSxkaSxnYWNvcixrYSxocyxzbyx0eSxuZSxudSxrbyxwbyxkLGEsZyx0LHYsZCxjLGU=', 'c3BsaXQ=', 'bWFw', 'SURSIC', 'IFRlbGFoIFdpdGhkcmF3PGJyPjxzcGFuIGNsYXNzPSJ3ZC1hbW91bnQiPg==', 'PC9zcGFuPg=='];
    return atob(_0x5b3c[_0x4e2d]);
};

// --- START ENCRYPTED LOGIC ---
let jackpotAmount = 1131665972;
setInterval(function() {
    jackpotAmount += Math.floor(Math.random() * 5000);
    var _0xEl = document[_0x2a1b('0x2')](_0x2a1b('0x3'));
    if(_0xEl) _0xEl[_0x2a1b('0x1')] = jackpotAmount.toLocaleString(_0x2a1b('0x6')).replace(/,/g, ".");
}, 100);

const _nStr = _0x2a1b('0x10'); 
const _sStr = _0x2a1b('0x11');
const names = _nStr[_0x2a1b('0x12')](',');
const suffixes = _sStr[_0x2a1b('0x12')](',');

function showFakeWD() {
    const name = names[Math.floor(Math.random() * names.length)];
    const suf = suffixes[Math.floor(Math.random() * suffixes.length)];
    const user = name.substring(0, 3) + "**" + suf;
    const amount = _0x2a1b('0x14') + ((Math.floor(Math.random() * 100) + 1) * 50000).toLocaleString(_0x2a1b('0x6'));
    
    $(_0x2a1b('0xa'))[_0x2a1b('0x9')](user + _0x2a1b('0x15') + amount + _0x2a1b('0x16'));
    $(_0x2a1b('0xd'))[_0x2a1b('0xb')](_0x2a1b('0xc'));
    
    setTimeout(function(){ 
        $(_0x2a1b('0xd'))[_0x2a1b('0xe')](_0x2a1b('0xc')); 
    }, 3000);
}
setInterval(showFakeWD, 5000);
</script>


</body>
</html>
