<?php
session_start();
include '../config/database.php';
include '../config/security_helper.php';

// Cek Sesi
if(isset($_SESSION['role'])){
    if($_SESSION['role'] == 'admin') header("location:../admin/dashboard.php");
    else header("location:loby.php");
    exit;
}

// Logic Captcha
if(empty($_SESSION['captcha_code'])){
    $chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    $_SESSION['captcha_code'] = substr(str_shuffle($chars), 0, 5);
}

// Variables Sticky Form
$old_user = isset($_POST['user']) ? htmlspecialchars($_POST['user']) : "";
$old_email = isset($_POST['email']) ? htmlspecialchars($_POST['email']) : "";
$old_telp = isset($_POST['phone-number']) ? htmlspecialchars($_POST['phone-number']) : "";
$old_bank_acc = isset($_POST['bank-account-name']) ? htmlspecialchars($_POST['bank-account-name']) : "";
$old_referral = isset($_POST['referral']) ? htmlspecialchars($_POST['referral']) : "";

$pesan_error = "";
$pesan_sukses = "";

if(isset($_POST['daftar'])){
    cek_csrf();

    if(!isset($_POST['captcha']) || strtoupper($_POST['captcha']) !== $_SESSION['captcha_code']){
        $pesan_error = "Captcha Salah!";
    } else {
        $username = strtolower(str_replace(' ', '', bersihkan_input($_POST['user'])));
        $no_telpon = preg_replace('/[^0-9]/', '', $_POST['phone-number']);
        $password = $_POST['password'];
        $email = bersihkan_input($_POST['email']);
        $nama_bank = bersihkan_input($_POST['bank-name']);
        $nomor_bank = preg_replace('/[^0-9]/', '', $_POST['bank-account-number']);
        $referral = bersihkan_input($_POST['referral']);

        if(strlen($username) < 3) {
            $pesan_error = "Username minimal 3 karakter.";
        } else {
            $cek = $koneksi->prepare("SELECT id FROM users WHERE username = ?");
            $cek->bind_param("s", $username);
            $cek->execute();
            
            if($cek->get_result()->num_rows > 0){
                $pesan_error = "Username sudah ada.";
            } else {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $koneksi->prepare("INSERT INTO users (username, no_telpon, password, email, nama_bank, nomor_bank, referral, role, saldo) VALUES (?, ?, ?, ?, ?, ?, ?, 'member', 0)");
                $stmt->bind_param("sssssss", $username, $no_telpon, $password_hash, $email, $nama_bank, $nomor_bank, $referral);
                
                if($stmt->execute()){
                    unset($_SESSION['captcha_code']);
                    $pesan_sukses = "Pendaftaran Berhasil!";
                    echo "<meta http-equiv='refresh' content='2;url=login.php'>";
                } else {
                    $pesan_error = "Gagal: " . $koneksi->error;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>WINSORTOTO ~ Daftar Akun</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        /* CSS ASLI DARI SOURCE CODE ANDA */
        * { box-sizing: border-box; outline: none; }
        body {
            background-color: #000;
            background-image: url("https://myimagehost.me/assets/bg-m-winsor-natal.jpg");
            background-size: cover;
            background-attachment: fixed;
            font-family: 'Roboto', sans-serif;
            margin: 0; padding: 0;
            color: #fff;
            padding-top: 70px; /* Space untuk Header Fixed */
            padding-bottom: 50px;
        }


        /* Container */
        .main-content { padding: 15px; max-width: 600px; margin: 0 auto; }

        /* Section Title */
        .section-title-form h3 {
            color: #ffd321; border-bottom: 1px solid #ffd321; padding-bottom: 5px;
            margin-bottom: 15px; text-transform: uppercase; font-size: 16px;
        }

        /* Form Styling (GELAP/GOLD SESUAI PERMINTAAN) */
        .form-group { margin-bottom: 15px; }
        .field-title { display: block; margin-bottom: 5px; color: #fff; font-size: 14px; font-weight: bold; }
        .required { color: red; }

        /* Input ASLI (Hitam + Border Emas) */
        .form-control {
            width: 100%; padding: 10px;
            background: #000; /* HITAM */
            border: 2px solid #f8c51e; /* EMAS */
            border-radius: 10px;
            color: #fff; /* TEXT PUTIH */
            font-size: 14px;
        }
        select.form-control { background: #000; color: #fff; }

        /* Input Group (Phone) */
        .input-group { display: flex; }
        .input-group-prepend {
            background: #f8c51e; color: #000; padding: 10px; border-radius: 10px 0 0 10px;
            font-weight: bold; border: 2px solid #f8c51e; display: flex; align-items: center;
        }
        .input-group input { border-top-left-radius: 0; border-bottom-left-radius: 0; }

        /* Captcha */
        .wrapper-captcha {
            display: flex; align-items: center; justify-content: center;
            background: #fff; padding: 5px; border-radius: 5px; margin-bottom: 10px;
        }
        .captcha-code { font-size: 24px; font-weight: bold; color: #000; letter-spacing: 5px; }

        /* Tombol Daftar */
        .button-reds {
            width: 100%; padding: 12px; border-radius: 14px; font-weight: bold; font-size: 16px;
            text-transform: uppercase; cursor: pointer;
            background: linear-gradient(150deg, #d19c16 10%, #e7b537 21%, #ffd11b 33%, #ffd52d 44%, #d19c16 60%, #e7b537 73%, #ffd11b 85%, #ffd52d 100%);
            background-size: 300% 300%; animation: mobile-button 3s ease infinite;
            border: 2px solid #ffd321; color: #000;
        }
        @keyframes mobile-button {
            0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; }
        }

        /* Alert */
        .alert { padding: 10px; margin-bottom: 10px; border-radius: 5px; text-align: center; color: white; font-weight: bold;}
        .alert-err { background: #cc0000; border: 1px solid red; }
        .alert-suc { background: #009900; border: 1px solid lime; }

        footer { text-align: center; font-size: 12px; color: #888; margin-top: 30px; border-top: 1px solid #333; padding-top: 10px;}
    </style>
</head>
<body>

    <?php include 'layout/header.php'; ?>


    <main class="main-content">
        
        <div class="section-title-form">
            <h3>Register Akun Baru</h3>
        </div>

        <?php if($pesan_error != ""): ?>
            <div class="alert alert-err"><?php echo $pesan_error; ?></div>
        <?php endif; ?>
        <?php if($pesan_sukses != ""): ?>
            <div class="alert alert-suc"><?php echo $pesan_sukses; ?></div>
        <?php endif; ?>

        <form method="POST">
            <?php input_csrf_token(); ?>
            
            <div class="form-group">
                <label class="field-title">Username <span class="required">*</span></label>
                <input type="text" class="form-control" name="user" value="<?php echo $old_user; ?>" placeholder="Username" required>
            </div>

            <div class="form-group">
                <label class="field-title">Password <span class="required">*</span></label>
                <input type="password" class="form-control" name="password" placeholder="Password" required>
            </div>

            <div class="form-group">
                <label class="field-title">Email <span class="required">*</span></label>
                <input type="email" class="form-control" name="email" value="<?php echo $old_email; ?>" placeholder="Email" required>
            </div>

            <div class="form-group">
                <label class="field-title">No. Telp/HP <span class="required">*</span></label>
                <div class="input-group">
                    <div class="input-group-prepend">+62</div>
                    <input type="tel" class="form-control" name="phone-number" value="<?php echo $old_telp; ?>" placeholder="812xxxxxx" required>
                </div>
            </div>

            <div class="form-group">
                <label class="field-title">Referral</label>
                <input type="text" class="form-control" name="referral" value="<?php echo $old_referral; ?>" placeholder="Kode Referral (Opsional)">
            </div>

            <div class="section-title-form" style="margin-top: 30px;">
                <h3>Data Bank</h3>
            </div>

            <div class="form-group">
                <label class="field-title">Nama Bank <span class="required">*</span></label>
                <select name="bank-name" class="form-control" required>
                    <option value="">-- Pilih Bank --</option>
                    <option value="BCA">BCA</option>
                    <option value="BNI">BNI</option>
                    <option value="BRI">BRI</option>
                    <option value="MANDIRI">MANDIRI</option>
                    <option value="DANA">DANA</option>
                    <option value="OVO">OVO</option>
                    <option value="GOPAY">GOPAY</option>
                </select>
            </div>

            <div class="form-group">
                <label class="field-title">Nama Rekening <span class="required">*</span></label>
                <input type="text" class="form-control" name="bank-account-name" value="<?php echo $old_bank_acc; ?>" placeholder="Sesuai Buku Tabungan" required>
            </div>

            <div class="form-group">
                <label class="field-title">Nomor Rekening <span class="required">*</span></label>
                <input type="tel" class="form-control" name="bank-account-number" placeholder="Nomor Rekening" required>
            </div>

            <div class="form-group">
                <label class="field-title">Validasi <span class="required">*</span></label>
                <div class="wrapper-captcha">
                    <div class="captcha-code"><?php echo $_SESSION['captcha_code']; ?></div>
                </div>
                <input type="text" class="form-control" name="captcha" placeholder="Masukkan kode di atas" required style="text-align: center; font-weight: bold; font-size: 18px;">
            </div>

            <div class="formSubmitButtonErrorsWrap" style="margin-top: 20px;">
                <button type="submit" name="daftar" class="button-reds">DAFTAR SEKARANG</button>
            </div>
        </form>
    </main>

    <footer>
        <p>&copy; Copyright 2025 WINSORTOTO. All Rights Reserved.</p>
    </footer>

</body>
</html>
