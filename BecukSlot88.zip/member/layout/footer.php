<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
    /* Jarak Bawah */
    body { padding-bottom: 90px !important; }

    /* OVERLAY GELAP */
    #bg-overlay {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.85); z-index: 9990;
        opacity: 0; pointer-events: none; transition: 0.2s;
        backdrop-filter: blur(3px);
    }
    #bg-overlay.show { opacity: 1; pointer-events: auto; }

    /* MENU BAWAH */
    .bottom-nav {
        position: fixed; bottom: 0; left: 0; width: 100%; height: 70px;
        background: #0f0f0f; border-top: 2px solid #ffd700;
        display: flex; justify-content: space-around; align-items: center;
        z-index: 9999; box-shadow: 0 -5px 20px rgba(0,0,0,0.9);
    }

    /* ITEM MENU STANDARD */
    .nav-item {
        flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
        text-decoration: none; background: none; border: none; cursor: pointer; height: 100%;
        color: #777; /* Warna Default Abu */
        transition: 0.2s;
    }
    .nav-item i { font-size: 24px; margin-bottom: 4px; transition: 0.2s; }
    .nav-item span { font-size: 10px; font-weight: 700; font-family: sans-serif; }

    /* --- STATE ACTIVE (SAAT DIPENCET) --- */
    /* Kita Paksa Pakai !important biar gak ada obat */
    .nav-item.active, .nav-item:hover { color: #ffd700 !important; }
    .nav-item.active i { 
        color: #ffd700 !important; 
        transform: translateY(-5px); 
        filter: drop-shadow(0 0 8px #ffd700);
    }

    /* KHUSUS TOMBOL DOMPET (WARNA SAAT AKTIF) */
    #btn-dompet.active-yellow {
        color: #ffd700 !important;
    }
    #btn-dompet.active-yellow i {
        color: #ffd700 !important;
        filter: drop-shadow(0 0 15px #ffd700) !important;
        transform: translateY(-8px) scale(1.1);
    }
    #btn-dompet.active-yellow span {
        color: #ffd700 !important;
        text-shadow: 0 0 5px #ffd700;
    }

    /* POPUP MENU DEPO/WD */
    .popup-dompet {
        position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%) scale(0);
        width: 220px; background: #1a1a1a; 
        border: 2px solid #ffd700; border-radius: 15px;
        padding: 10px; z-index: 10000;
        display: flex; flex-direction: column; gap: 8px;
        transition: 0.3s; opacity: 0; pointer-events: none;
        box-shadow: 0 0 25px rgba(255, 215, 0, 0.4);
    }
    .popup-dompet.show {
        bottom: 90px; opacity: 1; pointer-events: auto;
        transform: translateX(-50%) scale(1);
    }
    .popup-dompet::after {
        content: ''; position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%);
        border-width: 10px 10px 0; border-style: solid;
        border-color: #ffd700 transparent transparent transparent;
    }

    /* TOMBOL PILIHAN */
    .btn-pilih {
        display: flex; align-items: center; justify-content: center; gap: 10px;
        padding: 12px; border-radius: 10px; text-decoration: none;
        font-weight: 800; font-size: 13px; color: #fff;
    }
    .btn-depo { background: linear-gradient(to right, #00b09b, #96c93d); }
    .btn-wd   { background: linear-gradient(to right, #ff512f, #dd2476); }

    /* NOTIFIKASI WD */
    #fake-wd-container {
        position: fixed; top: 120px; right: 10px; z-index: 99999;
        display: flex; flex-direction: column; gap: 10px; pointer-events: none;
    }
    .wd-toast {
        background: rgba(0,0,0,0.95); border-left: 4px solid #00ff00;
        border-radius: 6px; padding: 10px 15px; width: 260px;
        display: flex; align-items: center; gap: 12px; color: #fff;
        font-family: sans-serif; opacity: 0; transform: translateX(50px);
        animation: slideMasuk 0.5s forwards, slideKeluar 0.5s forwards 4s;
    }
    @keyframes slideMasuk { to { opacity: 1; transform: translateX(0); } }
    @keyframes slideKeluar { to { opacity: 0; transform: translateY(-20px); } }
    .wd-nominal { color: #ffd700; font-weight: 800; font-size: 13px; }
</style>

<script>
    // FUNGSI GLOBAL (PASTI KEBACA)
    function toggleDompet() {
        var menu = document.getElementById("menu-transaksi");
        var overlay = document.getElementById("bg-overlay");
        var btn = document.getElementById("btn-dompet");

        if (menu && overlay && btn) {
            // TOGGLE KELAS 'show' UNTUK MENU
            if (menu.classList.contains("show")) {
                menu.classList.remove("show");
                overlay.classList.remove("show");
                // HAPUS WARNA KUNING
                btn.classList.remove("active-yellow");
            } else {
                menu.classList.add("show");
                overlay.classList.add("show");
                // TAMBAH WARNA KUNING
                btn.classList.add("active-yellow");
            }
        } else {
            console.log("Error: Elemen ID tidak ditemukan");
        }
    }
</script>

<div id="bg-overlay" onclick="toggleDompet()"></div>
<div id="fake-wd-container"></div>

<div id="menu-transaksi" class="popup-dompet">
    <a href="deposit.php" class="btn-pilih btn-depo">
        <i class="fa-solid fa-circle-down"></i> DEPOSIT
    </a>
    <a href="withdraw.php" class="btn-pilih btn-wd">
        <i class="fa-solid fa-circle-up"></i> WITHDRAW
    </a>
</div>

<nav class="bottom-nav">
    <a href="lobby.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'lobby.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-house"></i>
        <span>Beranda</span>
    </a>

    <div id="btn-dompet" class="nav-item" onclick="toggleDompet()">
        <i class="fa-solid fa-wallet" style="font-size: 28px;"></i>
        <span>Dompet</span>
    </div>

    <a href="https://secure.livechatenterprise.com/licence/11371927/v2/open_chat.cgi" target="_blank" class="nav-item">
        <i class="fa-solid fa-comments"></i>
        <span>Live Chat</span>
    </a>

    <a href="promosi.php" class="nav-item <?php echo (basename($_SERVER['PHP_SELF']) == 'promosi.php') ? 'active' : ''; ?>">
        <i class="fa-solid fa-gift"></i>
        <span>Promosi</span>
    </a>
</nav>
