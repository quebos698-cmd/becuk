<?php
$is_logged_in = isset($_SESSION['role']);
$username_header = isset($_SESSION['username']) ? $_SESSION['username'] : 'Member';
?>

<style>
    .site-header-wrapper {
        position: fixed; top: 0; left: 0; width: 100%;
        z-index: 9999; /* Header paling atas */
        box-shadow: 0 4px 8px rgba(0,0,0,0.5);
        background: #000; /* Background solid agar notif bisa sembunyi */
    }
    #snow-overlay {
        position: absolute; top: 0; left: 0; width: 100%; height: 100%;
        pointer-events: none; z-index: 100;
    }
    .top-bar {
        padding: 10px 15px;
        display: flex; justify-content: space-between; align-items: center;
        border-bottom: 1px solid #333;
        background: rgba(0,0,0,0.9); position: relative; z-index: 50; 
    }

    .logo-item img { max-height: 40px; vertical-align: midle; }

    /* Tombol Style */
    .btn-header {
        background: linear-gradient(to right bottom, #c59b2f 0%, #ffd11b 30%, #ffd52d 70%, #d1a536 95%);
        border: 2px solid #ffd321; color: #000; padding: 5px 15px;
        border-radius: 12px 4px; text-decoration: none; font-weight: bold; font-size: 12px;
        box-shadow: inset 0 0 5px 0px #b49138; display: inline-flex; align-items: center; gap: 5px;
        animation: changeColor 3s ease infinite;
    }
    @keyframes changeColor { 0% { color: #000; } 50% { color: #444; } 100% { color: #000; } }

    /* Marquee */
    .marquee-bar {
        background: linear-gradient(to bottom, #d6a528, #f3db06, #d19c16);
        border-bottom: 2px solid #ffd321; border-top: 2px solid #ffd321;
        color: #000; font-weight: bold; font-size: 12px; padding: 6px 0;
        width: 100%; overflow: hidden; white-space: nowrap;
        position: relative; z-index: 50; /* Di atas notifikasi */
    }
    .marquee-child { display: inline-block; padding-left: 100%; animation: marquee 15s linear infinite; }
    @keyframes marquee { 0% { transform: translate(0, 0); } 100% { transform: translate(-100%, 0); } }

    .user-info { color: #ffd321; font-size: 12px; font-weight: bold; margin-right: 10px; }

    #header-notif-wrapper {
        position: absolute;
        top: 100%; /* Menempel di bawah header */
        left: 0; width: 100%;
        display: flex; justify-content: center;
        z-index: -1; /* Sembunyi di belakang header */
        pointer-events: none; overflow: hidden; 
    }

    .header-toast {
        background: rgba(0, 0, 0, 0.95);
        border: 1px solid #ffd700;
        border-top: none;
        border-radius: 0 0 12px 12px; /* Radius lebih besar */
        padding: 8px 25px; /* Padding diperbesar (Atas/Bawah 8px, Kiri/Kanan 25px) */
        display: flex; align-items: center; gap: 10px;
        color: #fff; font-family: sans-serif; 
        font-size: 12px; /* Font size naik dikit dari 11px */
        box-shadow: 0 10px 20px rgba(0,0,0,0.6);
        
        /* Animasi Slide Lebih Cepat (0.3s) */
        transform: translateY(-100%); 
        transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .header-toast.show { transform: translateY(0); }

    .wd-icon { color: #00ff00; font-size: 16px; animation: pulse 1s infinite; } /* Icon lebih besar */
    .wd-text { font-weight: bold; color: #eee; }
    .wd-amount { color: #ffd700; font-weight: 800; font-size: 13px; margin-left: 5px; } /* Nominal lebih besar */
    .wd-bank { color: #aaa; font-style: italic; border-left: 1px solid #555; padding-left: 8px; margin-left: 5px; }

    @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }
</style>

<div class="site-header-wrapper" id="header-container">
    
    <canvas id="snow-overlay"></canvas>

    <div class="top-bar">
        <div class="logo-item">
            <a href="/">
                <img src="https://i.ibb.co.com/S7N08s1Y/14-53-0.png" alt="Logo">
            </a>
        </div>
        <div>
            <?php if($is_logged_in): ?>
                <a href="../../member/deposit.php" class="btn-header" style="background: linear-gradient(to bottom, #ff4444, #cc0000); border-color: red; color: white;">DEPOSIT</a>
                <a href="logout.php" class="btn-header" style="background: linear-gradient(to bottom, #ff4444, #cc0000); border-color: red; color: white;">LOGOUT</a>
            <?php else: ?>
                <a href="../../member/login.php" class="btn-header">LOGIN</a>
                <a href="#" class="btn-header">LIVE CHAT</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="marquee-bar">
        <div class="marquee-child">
            Selamat datang di KINGHOKI88 - Pusat Game Toto Togel & Slot Online Pilihan Terbaik 2025 | Transaksi Cepat & Aman. 
        </div>
    </div>

    <div id="header-notif-wrapper"></div>
</div>

<script>
    (function() {
        var canvas = document.getElementById("snow-overlay");
        if (!canvas) return;
        var ctx = canvas.getContext("2d");
        var particles = [];
        var width, height;
        var isMobile = window.innerWidth < 768;
        var flakesCount = isMobile ? 30 : 70; 

        function resize() { width = canvas.width = canvas.parentNode.offsetWidth; height = canvas.height = canvas.parentNode.offsetHeight; }
        function init() { resize(); for (var i = 0; i < flakesCount; i++) { particles.push({ x: Math.random() * width, y: Math.random() * height, velY: (Math.random() * 1) + 0.5, velX: 0, size: (Math.random() * 2) + 1, stepSize: (Math.random() / 30), step: 0, opacity: (Math.random() * 0.5) + 0.3 }); } snow(); }
        function snow() { ctx.clearRect(0, 0, width, height); for (var i = 0; i < flakesCount; i++) { var p = particles[i]; ctx.fillStyle = "rgba(255,255,255," + p.opacity + ")"; ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill(); p.y += p.velY; p.x += Math.cos(p.step += p.stepSize) * 0.5; if (p.y > height || p.x > width || p.x < 0) { p.x = Math.floor(Math.random() * width); p.y = 0; } } requestAnimationFrame(snow); }
        window.addEventListener("resize", resize); init();
    })();
    (function(){
        const userNames = ["Aditya", "Pratama", "Budi", "Santoso", "Citra", "Kirana", "Dewi", "Lestari", "Eko", "Kurniawan", "Fajar", "Hidayat", "Gita", "Gutawa", "Hendra", "Gunawan", "Indah", "Permatasari", "Joko", "Susilo", "Kevin", "Wijaya", "Larasati","Nugroho",  "Muhammad", "Rizky", "Nadia", "Safira", "Oscar", "Mahendra", "Putri", "Ayu",  "Qory", "Sandioriva", "Rina", "Wulandari", "Siti", "Aminah", "Taufik", "Hidayat", "Usman", "Said", "Vina", "Panduwinata", "Wahyu", "Saputra", "Xavier", "Tan", "Yulia", "Kartika", "Zainal", "Abidin", "Agus", "Setiawan", "Bayu", "Nugraha", "Clarissa", "Putri", "Dimas", "Anggara"];
        const banks = ["BCA", "BNI", "BRI", "MANDIRI", "DANA", "OVO", "GOPAY"];

        function formatRupiah(num) { return 'IDR ' + num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.'); }
        
        function randomInt(min, max) { return Math.floor(Math.random() * (max - min + 1) + min); }

        function showHeaderNotif() {
            const wrapper = document.getElementById('header-notif-wrapper');
            let name = userNames[randomInt(0, userNames.length - 1)].substring(0,3) + "***";
            let bank = banks[randomInt(0, banks.length - 1)];
            
            let finalAmount;
            let step = 50000; // Kelipatan 50rb
            
            let isSmallWD = Math.random() < 0.8; 

            if (isSmallWD) {
                // RANGE KECIL: 500.000 - 5.000.000
                let min = 500000; 
                let max = 5000000;
                // Rumus matematika untuk kelipatan:
                // (Random 0-90) * 50.000 + 500.000
                let stepsCount = (max - min) / step;
                let randomStep = Math.floor(Math.random() * (stepsCount + 1));
                finalAmount = min + (randomStep * step);
            } else {
                // RANGE BESAR: 5.050.000 - 24.000.000
                let min = 5050000; 
                let max = 24000000;
                let stepsCount = (max - min) / step;
                let randomStep = Math.floor(Math.random() * (stepsCount + 1));
                finalAmount = min + (randomStep * step);
            }
            
            let amountStr = formatRupiah(finalAmount);

            const el = document.createElement('div');
            el.className = 'header-toast';
            el.innerHTML = `
                <i class="fa fa-check-circle wd-icon" style="color:#00ff00;"></i>
                <div class="wd-text">
                    ${name} SUKSES WD <span class="wd-amount">${amountStr}</span>
                    <span class="wd-bank">via ${bank}</span>
                </div>
            `;

            wrapper.innerHTML = '';
            wrapper.appendChild(el);

            setTimeout(() => { el.classList.add('show'); }, 50);
            setTimeout(() => { el.classList.remove('show'); }, 4000); 
        }

        function startLoop() {
            let delay = randomInt(4000, 10000); // Muncul tiap 4-10 detik
            setTimeout(() => {
                showHeaderNotif();
                startLoop();
            }, delay);
        }
        
        setTimeout(startLoop, 2000);
    })();
</script>