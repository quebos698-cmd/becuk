<?php
session_start();

// 1. CEK LOGIN
if (!isset($_SESSION['username'])) {
    header("Location: ../../../login.php"); 
    exit;
}

// 2. USERNAME HARDCODED
$api_username = "oabecuk888yf"; 

// CONFIG URL
$api_base = "https://endpoint-api-cxfteams.sbs/game/";
$demo_base = "https://demogamesfree.pragmaticplay.net/gs2c/openGame.do?lang=id&cur=IDR&gameSymbol=";

$games = [
    [ "name" => "Gates of Olympus", "api" => "GatesofOlympusM", "demo" => "vs20olympgate", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/GatesOfOlympusM.jpg" ],
    [ "name" => "Starlight Princess", "api" => "StarlightPrincessM", "demo" => "vs20starlight", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/StarlightPrincessM.jpg" ],
    [ "name" => "Sweet Bonanza", "api" => "SweetBonanzaM", "demo" => "vs20fruitsw", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/SweetBonanzaM.jpg" ],
    [ "name" => "Aztec Gems", "api" => "AztecGemsPMM", "demo" => "vs5aztecgems", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/AztecGemsPMM.jpg" ],
    [ "name" => "Sweet Bonanza Xmas", "api" => "SweetBonanzaXmasM", "demo" => "vs20sbxmas", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/SweetBonanzaXmasM.jpg" ],
    [ "name" => "Starlight Christmas", "api" => "StarlightChristmasM", "demo" => "vs20schristmas", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/StarlightChristmasM.jpg" ],
    [ "name" => "Sugar Rush", "api" => "SugarRushM", "demo" => "vs20sugarrush", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/SugarRushM.jpg" ],
    [ "name" => "The Dog House", "api" => "TheDogHouseM", "demo" => "vs20doghouse", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/TheDogHouseM.jpg" ],
    [ "name" => "Great Rhino", "api" => "GreatRhinoPMM", "demo" => "vs20rhino", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/GreatRhinoPMM.jpg" ],
    [ "name" => "888 Dragons", "api" => "Dragons888PMM", "demo" => "vs5888dragons", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/Dragons888PMM.jpg" ],
    [ "name" => "Joker's Jewel", "api" => "JokersJewelPMM", "demo" => "vs5joker", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/JokersJewelPMM.jpg" ],
    [ "name" => "Peking Luck", "api" => "PekingLuckPMM", "demo" => "vs25peking", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/PekingLuckPMM.jpg" ],
    [ "name" => "Tweety House", "api" => "TweetyHouseM", "demo" => "vs20tweetyhouse", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/TweetyHouseM.jpg" ],
    [ "name" => "Day of Dead", "api" => "DayOfDeadM", "demo" => "vs20daydead", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/DayOfDeadM.jpg" ],
    [ "name" => "Pyramid Bonanza", "api" => "PyramidBonanzaM", "demo" => "vs20pyramid", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/PyramidBonanzaM.jpg" ],
    [ "name" => "Candy Village", "api" => "CandyVillageM", "demo" => "vs20candyvill", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/CandyVillageM.jpg" ],
    [ "name" => "Big Bass Bonanza", "api" => "BigBassBonanzaM", "demo" => "vs10bbbonanza", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/BigBassBonanzaM.jpg" ],
    [ "name" => "Wolf Gold", "api" => "WolfGoldM", "demo" => "vs25wolfgold", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/WolfGoldM.jpg" ],
    [ "name" => "Santa's Great Gifts", "api" => "SantasGreatGiftsM", "demo" => "vs20santa", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/SantasGreatGiftsM.jpg" ],
    [ "name" => "Ancient Egypt", "api" => "AncientEgyptPMM", "demo" => "vs10egypt", "img" => "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/AncientEgyptPMM.jpg" ]
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    
    <title>PRAGMATIC PLAY</title>
    
    <style>
        /* RESET DASAR */
        * { box-sizing: border-box; }
        
        body {
            background-color: #000;
            background-image: url("https://myimagehost.me/assets/bg-m-winsor-natal.jpg"); 
            background-size: cover; background-attachment: fixed; background-position: center;
            color: #fff; font-family: sans-serif;
            margin: 0; padding: 0; padding-bottom: 80px;
        }
        
        /* HEADER (Include dari PHP nanti akan muncul di atas ini) */
        .provider-title {
            text-align: center; margin: 15px 0;
            border-bottom: 1px solid #ffd700; padding-bottom: 5px;
        }
        .provider-title h2 {
            margin: 0; color: #ffd700; font-size: 18px; font-weight: 800;
            text-transform: uppercase; text-shadow: 0 1px 3px #000;
        }

        /* GRID SYSTEM (PAKSA 3 KOLOM DI SEMUA LAYAR) */
        .game-grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 Kolom */
            gap: 8px; /* Jarak antar kotak */
            padding: 10px;
        }

        /* KARTU GAME */
        .game-card-item {
            position: relative;
            background: #111;
            border: 1px solid #444;
            border-radius: 8px;
            overflow: hidden;
            /* Aspek Rasio agar kotak tidak gepeng */
            aspect-ratio: 1 / 1; 
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.5);
            transition: all 0.2s;
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        /* EFEK KLIK */
        .game-card-item.active {
            border-color: #ffd700;
            box-shadow: 0 0 10px rgba(255, 215, 0, 0.6);
            z-index: 10;
        }

        /* GAMBAR */
        .game-thumb-img {
            width: 100%; height: 100%; object-fit: cover;
            transition: 0.2s;
        }
        .game-card-item.active .game-thumb-img {
            filter: blur(3px) brightness(0.4);
            transform: scale(1.1);
        }

        /* LABEL NAMA (Ukuran Font Kecil untuk HP) */
        .game-name-label {
            position: absolute; bottom: 0; left: 0; width: 100%;
            background: rgba(0,0,0,0.9); color: #fff;
            font-size: 9px; /* Font Pas untuk 3 Kolom */
            text-align: center; padding: 4px 0;
            font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
            z-index: 5; border-top: 1px solid #333;
        }

        /* OVERLAY TOMBOL */
        .action-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            display: flex; flex-direction: column; 
            justify-content: center; align-items: center;
            gap: 6px; 
            opacity: 0; pointer-events: none; transition: 0.2s; z-index: 10;
        }

        .game-card-item.active .action-overlay { opacity: 1; pointer-events: auto; }

        /* TOMBOL MAIN & DEMO */
        .btn-play-game {
            text-decoration: none; width: 85%;
            padding: 5px 0; text-align: center;
            border-radius: 20px; font-weight: 800; font-size: 10px;
            transform: scale(0.8); transition: transform 0.2s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.8);
            display: block; /* Agar tombol rapi ke bawah */
        }

        .btn-gold { background: linear-gradient(to bottom, #d4af37, #b8860b); color: #000; border: 1px solid #fff; }
        .btn-blue { background: linear-gradient(to bottom, #3498db, #2980b9); color: #fff; border: 1px solid #85c1e9; }

        .game-card-item.active .btn-play-game { transform: scale(1); }

        /* TOMBOL KEMBALI */
        .btn-back-home {
            display: block; width: 90%; margin: 20px auto; text-align: center;
            padding: 12px; background: #222; color: #fff;
            text-decoration: none; border-radius: 8px; border: 1px solid #444; font-weight: bold; font-size: 14px;
        }
    </style>
</head>
<body>

    <?php include '../../member/layout/header.php'; ?>
    </br>
        </br>
        </br>
            </br>
                </br>
    <div class="provider-title">
        <h2>PRAGMATIC PLAY</h2>
    </div>

    <div class="game-grid-container">
        <?php foreach($games as $gm): 
            $link_main = $api_base . $gm['api'] . "?username=" . $api_username;
            $link_demo = $demo_base . $gm['demo'];
        ?>

        <div class="game-card-item" onclick="toggleCard(this)">
            <img src="<?php echo $gm['img']; ?>" class="game-thumb-img" loading="lazy" alt="<?php echo $gm['name']; ?>">
            <div class="game-name-label"><?php echo $gm['name']; ?></div>

            <div class="action-overlay">
                <a href="<?php echo $link_main; ?>" class="btn-play-game btn-gold" target="_blank">MAIN</a>
                <a href="<?php echo $link_demo; ?>" class="btn-play-game btn-blue" target="_blank">DEMO</a>
            </div>
        </div>

        <?php endforeach; ?>
    </div>

    <a href="../../member/lobby.php" class="btn-back-home">KEMBALI KE LOBBY</a>

    <script>
        function toggleCard(el) {
            var cards = document.querySelectorAll('.game-card-item');
            cards.forEach(c => { if(c !== el) c.classList.remove('active'); });
            el.classList.toggle('active');
        }
    </script>

    <?php include '../../member/layout/footer.php'; ?>

</body>
</html>
