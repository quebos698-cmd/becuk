<?php
session_start();

// 1. CEK LOGIN (WAJIB)
if (!isset($_SESSION['username'])) {
    // Coba redirect ke login dengan beberapa kemungkinan path
    if(file_exists('../../../login.php')) { header("Location: ../../../login.php"); }
    elseif(file_exists('../../login.php')) { header("Location: ../../login.php"); }
    else { header("Location: /login.php"); }
    exit;
}

// =================================================================================
// 2. SMART INCLUDE HEADER (ANTI ERROR)
// =================================================================================
// Script ini akan mencari file header.php di berbagai folder mundur
$header_paths = [
    '../../../layout/header.php',         // Mundur 3 langkah (Standar)
    '../../layout/header.php',            // Mundur 2 langkah
    '../../../../layout/header.php',      // Mundur 4 langkah
    '../../../member/layout/header.php',  // Masuk ke folder member dulu
    '../../member/layout/header.php'
];

$header_found = false;
foreach ($header_paths as $path) {
    if (file_exists($path)) {
        include $path;
        $header_found = true;
        break;
    }
}

// Jika header tidak ketemu sama sekali (Debug)
if (!$header_found) {
    echo "<div style='background:red;color:white;padding:10px;text-align:center;'>WARNING: Header file not found! Cek path folder layout.</div>";
}

// =================================================================
// KONFIGURASI PLAY'N GO
// =================================================================
$api_username = "oabecuk888yf"; // USERNAME HARDCODED

$api_base = "https://endpoint-api-cxfteams.sbs/game/";
$img_base = "https://cxfteams-games-cloning-slots-gambling.sbs/frontend/Default/ico/";

// DATA GAME (8 GAME DARI SOURCE)
$games = [
    [ "code" => "CasinoHoldemPG", "name" => "Casino Hold'em", "img" => "CasinoHoldemPG.jpg" ],
    [ "code" => "LeprechaunGoesWildPG", "name" => "Leprechaun Goes Wild", "img" => "LeprechaunGoesWildPG.jpg" ],
    [ "code" => "RichesOfRobinPG", "name" => "Riches of Robin", "img" => "RichesOfRobinPG.jpg" ],
    [ "code" => "RichWildeAndTheShieldOfAthenaPG", "name" => "Shield of Athena", "img" => "RichWildeAndTheShieldOfAthenaPG.jpg" ],
    [ "code" => "RingOfOdinPG", "name" => "Ring of Odin", "img" => "RingOfOdinPG.jpg" ],
    [ "code" => "SuperWheelPG", "name" => "Super Wheel", "img" => "SuperWheelPG.jpg" ],
    [ "code" => "SweetAlchemyBingoPG", "name" => "Sweet Alchemy Bingo", "img" => "SweetAlchemyBingoPG.jpg" ],
    [ "code" => "TrollHunters2PG", "name" => "Troll Hunters 2", "img" => "TrollHunters2PG.jpg" ]
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>PLAY'N GO - SLOT GACOR</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* SETUP BODY (PADDING AGAR TIDAK NABRAK HEADER) */
        body {
            background-color: #000;
            /* Pastikan file gambar background ada, kalau tidak ada layar akan hitam polos */
            background-image: url("https://myimagehost.me/assets/bg-m-winsor-natal.jpg"); 
            background-size: cover; background-attachment: fixed; background-position: center;
            color: #fff; font-family: sans-serif;
            margin: 0; padding-top: 90px; padding-bottom: 20px;
        }
        .bg-overlay {
            position: fixed; top:0; left:0; width:100%; height:100%;
            background: rgba(0,0,0,0.85); z-index: -1;
        }

        /* HEADER JUDUL (TEMA EMAS) */
        .judul-halaman {
            text-align: center; margin-bottom: 20px; position: relative;
        }
        .judul-halaman h3 {
            margin: 0; display: inline-block;
            color: #ffd700; /* EMAS */
            font-size: 18px; font-weight: 800; text-transform: uppercase;
            border-bottom: 2px solid #ffd700; padding-bottom: 5px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.8);
        }

        /* GRID 3 KOLOM RESPONSIVE (MOBILE FRIENDLY) */
        .game-grid-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* WAJIB 3 KOLOM DI HP */
            gap: 8px; padding: 10px;
        }
        
        /* PC MODE (Lebih lebar) */
        @media (min-width: 992px) {
            .game-grid-container { grid-template-columns: repeat(6, 1fr); gap: 15px; }
        }

        /* KARTU GAME */
        .game-card-item {
            position: relative;
            background: #111;
            border: 1px solid #444; 
            border-radius: 8px;
            overflow: hidden;
            aspect-ratio: 1 / 1; 
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.5);
            transition: all 0.2s;
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        /* EFEK KLIK (EMAS) */
        .game-card-item.active {
            border-color: #ffd700;
            box-shadow: 0 0 15px rgba(255, 215, 0, 0.5);
            z-index: 10;
        }

        /* GAMBAR */
        .game-thumb-img {
            width: 100%; height: 100%; object-fit: cover;
            transition: 0.2s;
        }
        .game-card-item.active .game-thumb-img {
            filter: blur(3px) brightness(0.4);
            transform: scale(1.1);
        }

        /* LABEL NAMA */
        .game-name-label {
            position: absolute; bottom: 0; left: 0; width: 100%;
            background: rgba(0,0,0,0.9); color: #fff;
            font-size: 9px; text-align: center; padding: 4px 0;
            font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
            z-index: 5; border-top: 1px solid #333;
        }

        /* OVERLAY TOMBOL */
        .action-overlay {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            display: flex; justify-content: center; align-items: center;
            opacity: 0; pointer-events: none; transition: 0.2s; z-index: 10;
        }

        .game-card-item.active .action-overlay { opacity: 1; pointer-events: auto; }

        /* TOMBOL MAIN (GRADASI EMAS) */
        .btn-play-game {
            text-decoration: none;
            background: linear-gradient(to bottom, #d4af37, #b8860b);
            color: #000; border: 1px solid #fff;
            padding: 8px 25px; text-align: center;
            border-radius: 20px; font-weight: 900; font-size: 12px;
            transform: scale(0); transition: transform 0.3s;
            box-shadow: 0 4px 10px rgba(0,0,0,0.8);
        }

        .game-card-item.active .btn-play-game { transform: scale(1); }

        /* TOMBOL KEMBALI */
        .btn-back-home {
            display: block; width: 90%; margin: 30px auto; text-align: center;
            padding: 12px; background: #222; color: #fff;
            text-decoration: none; border-radius: 8px; border: 1px solid #444; font-weight: bold;
        }
    </style>
</head>
<body>
</br>
    <div class="bg-overlay"></div>

    <div class="judul-halaman">
        <h3>PLAY'N GO</h3>
    </div>

    <div class="game-grid-container">
        <?php foreach($games as $gm): 
            // LINK MAIN (API + USERNAME)
            $link_main = $api_base . $gm['code'] . "?username=" . $api_username;
            // GAMBAR
            $link_img  = $img_base . $gm['img'];
        ?>

        <div class="game-card-item" onclick="toggleCard(this)">
            <img src="<?php echo $link_img; ?>" class="game-thumb-img" loading="lazy" alt="<?php echo $gm['name']; ?>">
            <div class="game-name-label"><?php echo $gm['name']; ?></div>

            <div class="action-overlay">
                <a href="<?php echo $link_main; ?>" class="btn-play-game" target="_blank">
                    <i class="fa fa-play"></i> MAIN
                </a>
            </div>
        </div>

        <?php endforeach; ?>
    </div>

    <?php
        $lobby_url = "../../../member/loby.php"; // Default
        if(file_exists("../../lobby.php")) { $lobby_url = "../../lobby.php"; }
        elseif(file_exists("../../../lobby.php")) { $lobby_url = "../../../lobby.php"; }
    ?>
    <a href="<?php echo $lobby_url; ?>" class="btn-back-home">KEMBALI KE LOBBY</a>

    <script>
        function toggleCard(el) {
            var cards = document.querySelectorAll('.game-card-item');
            cards.forEach(c => { if(c !== el) c.classList.remove('active'); });
            el.classList.toggle('active');
        }
    </script>

<?php 
// =================================================================================
// 3. SMART INCLUDE FOOTER (ANTI ERROR)
// =================================================================================
$footer_paths = [
    '../../../layout/footer.php',
    '../../layout/footer.php',
    '../../../../layout/footer.php',
    '../../../member/layout/footer.php',
    '../../member/layout/footer.php'
];

foreach ($footer_paths as $path) {
    if (file_exists($path)) {
        include $path;
        break;
    }
}
?>

</body>
</html>
