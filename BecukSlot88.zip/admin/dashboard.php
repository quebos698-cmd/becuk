<?php
session_start();
include '../config/database.php';

// 1. CEK LOGIN ADMIN
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("location:../member/login.php");
    exit;
}

// 2. LOGIKA TOMBOL ACC/TOLAK
if(isset($_POST['tombol_aksi_dashboard'])){
    $id_trx = $_POST['id_trx_target'];
    $aksi   = $_POST['tombol_aksi_dashboard']; 
    
    $cek_data = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE id='$id_trx' AND status='pending'");
    $dt = mysqli_fetch_assoc($cek_data);
    
    if($dt){
        $user_id = $dt['user_id'];
        $nominal = $dt['jumlah'];
        $tipe    = $dt['tipe_transaksi'];
        
        if($aksi == 'terima'){
            if($tipe == 'masuk'){
                mysqli_query($koneksi, "UPDATE users SET saldo = saldo + $nominal WHERE id='$user_id'");
            }
            mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status='sukses', keterangan=CONCAT(keterangan, ' [ACC]') WHERE id='$id_trx'");
            $pesan = "<div class='alert alert-success alert-dismissible fade show'><strong>SUKSES!</strong> Transaksi di-ACC.<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
        } else {
            mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status='batal', keterangan=CONCAT(keterangan, ' [Ditolak]') WHERE id='$id_trx'");
            $pesan = "<div class='alert alert-danger alert-dismissible fade show'><strong>DITOLAK!</strong> Transaksi dibatalkan.<button type='button' class='btn-close' data-bs-dismiss='alert'></button></div>";
        }
    }
}

// 3. HITUNG TOTAL
$total_member = mysqli_num_rows(mysqli_query($koneksi, "SELECT id FROM users WHERE role='member'"));
$depo_pending = mysqli_num_rows(mysqli_query($koneksi, "SELECT id FROM riwayat_transaksi WHERE tipe_transaksi='masuk' AND status='pending'"));
$wd_pending   = mysqli_num_rows(mysqli_query($koneksi, "SELECT id FROM riwayat_transaksi WHERE tipe_transaksi='keluar' AND status='pending'"));

// 4. DATA LIVE DEPOSIT
$live_depo = mysqli_query($koneksi, "
    SELECT t.*, u.username, u.saldo 
    FROM riwayat_transaksi t 
    JOIN users u ON t.user_id = u.id 
    WHERE t.tipe_transaksi='masuk' AND t.status='pending' 
    ORDER BY t.tanggal ASC LIMIT 10
");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Dashboard Admin</title>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', sans-serif; overflow-x: hidden; }
        
        /* --- SIDEBAR RESPONSIVE --- */
        .sidebar {
            width: 260px; height: 100vh; position: fixed; top: 0; left: 0;
            background: #1e1e2d; color: #fff; z-index: 1050;
            transition: all 0.3s;
        }
        .sidebar-brand { padding: 20px; text-align: center; font-weight: bold; font-size: 20px; color: #ffd700; border-bottom: 1px solid #333; }
        .sidebar a {
            display: block; color: #a6a7b0; padding: 15px 20px; text-decoration: none; font-weight: 500;
            border-left: 4px solid transparent;
        }
        .sidebar a:hover, .sidebar a.active { background: #2a2a3c; color: #fff; border-left-color: #ffd700; }
        
        /* Overlay untuk Mobile saat menu terbuka */
        .overlay { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1040; }

        /* --- CONTENT UTAMA --- */
        .main-content { margin-left: 260px; padding: 20px; transition: all 0.3s; }
        
        /* TOMBOL MENU MOBILE */
        .btn-toggle-menu { display: none; background: #1e1e2d; color: #fff; border: none; padding: 10px 15px; border-radius: 5px; margin-bottom: 15px; }

        /* CARDS */
        .card-stat { 
            border: none; border-radius: 12px; padding: 20px; color: #fff; 
            margin-bottom: 15px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); 
            display: flex; justify-content: space-between; align-items: center;
        }
        .bg-1 { background: linear-gradient(135deg, #4e73df, #224abe); }
        .bg-2 { background: linear-gradient(135deg, #1cc88a, #13855c); }
        .bg-3 { background: linear-gradient(135deg, #e74a3b, #be2617); }
        .stat-icon { font-size: 40px; opacity: 0.3; }

        /* TABLE */
        .card-table { background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); overflow: hidden; }
        .card-header-custom { background: #343a40; color: #fff; padding: 15px; font-weight: bold; display: flex; justify-content: space-between; align-items: center; }
        
        /* Tombol Aksi Besar di HP */
        .btn-aksi { padding: 8px 15px; border-radius: 5px; border:none; font-weight: bold; color: #fff; font-size: 14px; }
        .btn-acc { background: #28a745; margin-right: 5px; }
        .btn-tolak { background: #dc3545; }

        /* --- MEDIA QUERY (HP) --- */
        @media (max-width: 768px) {
            .sidebar { left: -260px; } /* Sembunyikan sidebar */
            .sidebar.active { left: 0; } /* Munculkan sidebar */
            .main-content { margin-left: 0; padding: 15px; }
            .btn-toggle-menu { display: inline-block; } /* Tampilkan tombol menu */
            .overlay.active { display: block; }
            
            /* Font Tabel Kecil di HP */
            .table { font-size: 12px; }
            .btn-aksi { padding: 5px 10px; font-size: 11px; }
            
            h3 { font-size: 18px; }
        }
    </style>
</head>
<body>

    <div class="overlay" id="overlay" onclick="toggleMenu()"></div>

    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">PANEL ADMIN</div>
        <a href="dashboard.php" class="active"><i class="fa fa-tachometer-alt me-2"></i> DASHBOARD</a>
        <a href="kelola_member.php"><i class="fa fa-users me-2"></i> DATA MEMBER</a>
        <a href="riwayat_transaksi.php"><i class="fa fa-list-alt me-2"></i> TRANSAKSI</a>
        <a href="../member/logout.php" class="text-danger mt-4"><i class="fa fa-sign-out-alt me-2"></i> LOGOUT</a>
    </div>

    <div class="main-content">
        
        <button class="btn-toggle-menu" onclick="toggleMenu()">
            <i class="fa fa-bars"></i> MENU
        </button>

        <h3 class="fw-bold mb-4">Dashboard Overview</h3>
        
        <?php if(isset($pesan)) echo $pesan; ?>

        <div class="row">
            <div class="col-12 col-md-4">
                <div class="card-stat bg-1">
                    <div>
                        <small>TOTAL MEMBER</small>
                        <h2 class="m-0 fw-bold"><?php echo $total_member; ?></h2>
                    </div>
                    <i class="fa fa-users stat-icon"></i>
                </div>
            </div>
            <div class="col-6 col-md-4">
                <div class="card-stat bg-2">
                    <div>
                        <small>DEPO PENDING</small>
                        <h2 class="m-0 fw-bold"><?php echo $depo_pending; ?></h2>
                    </div>
                    <i class="fa fa-arrow-down stat-icon"></i>
                </div>
            </div>
            <div class="col-6 col-md-4">
                <div class="card-stat bg-3">
                    <div>
                        <small>WD PENDING</small>
                        <h2 class="m-0 fw-bold"><?php echo $wd_pending; ?></h2>
                    </div>
                    <i class="fa fa-arrow-up stat-icon"></i>
                </div>
            </div>
        </div>

        <div class="card card-table mt-4">
            <div class="card-header-custom">
                <span><i class="fa fa-bolt text-warning me-2"></i> DEPOSIT MASUK</span>
                <button class="btn btn-sm btn-light" onclick="location.reload()"><i class="fa fa-sync"></i></button>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 text-nowrap">
                    <thead class="table-light">
                        <tr>
                            <th>Waktu</th>
                            <th>Member</th>
                            <th>Via</th>
                            <th>Nominal</th>
                            <th class="text-center">Aksi Cepat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($live_depo) > 0) { 
                            while($row = mysqli_fetch_assoc($live_depo)) { ?>
                            <tr>
                                <td><?php echo date('H:i', strtotime($row['tanggal'])); ?></td>
                                <td>
                                    <strong><?php echo $row['username']; ?></strong>
                                    <div class="text-muted" style="font-size:10px;">Saldo: <?php echo number_format($row['saldo']); ?></div>
                                </td>
                                <td><span class="badge bg-secondary"><?php echo $row['keterangan']; ?></span></td>
                                <td class="text-success fw-bold">Rp <?php echo number_format($row['jumlah']); ?></td>
                                <td class="text-center">
                                    <form method="POST">
                                        <input type="hidden" name="id_trx_target" value="<?php echo $row['id']; ?>">
                                        
                                        <button type="submit" name="tombol_aksi_dashboard" value="terima" class="btn-aksi btn-acc" onclick="return confirm('ACC Deposit ini?')">
                                            <i class="fa fa-check"></i> ACC
                                        </button>
                                        
                                        <button type="submit" name="tombol_aksi_dashboard" value="tolak" class="btn-aksi btn-tolak" onclick="return confirm('Tolak?')">
                                            <i class="fa fa-times"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php }} else { ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    Belum ada deposit baru.
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script>
        // Fungsi Buka Tutup Menu di HP
        function toggleMenu() {
            document.getElementById('sidebar').classList.toggle('active');
            document.getElementById('overlay').classList.toggle('active');
        }

        // Auto Refresh Data 15 Detik
        setTimeout(function(){
           window.location.reload(1);
        }, 15000);
    </script>

</body>
</html>