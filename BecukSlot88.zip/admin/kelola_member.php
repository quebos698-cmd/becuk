<?php
// 1. SETUP & KEAMANAN
session_start();
include '../config/database.php';      
include '../config/security_helper.php';

// Cek Admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("location:login.php");
    exit;
}

// 2. LOGIKA PENCARIAN
$keyword = "";
$query_str = "SELECT * FROM users WHERE role='member'";

if (isset($_GET['cari'])) {
    $keyword = bersihkan_input($_GET['keyword']);
    $query_str .= " AND (username LIKE '%$keyword%' OR no_telpon LIKE '%$keyword%')";
}

// Urutkan dari yang terbaru
$query_str .= " ORDER BY id DESC LIMIT 100";

$result = mysqli_query($koneksi, $query_str);

// SIMPAN DATA KE ARRAY DULU (Agar bisa dipakai 2x untuk Tampilan HP & Laptop)
$data_members = [];
while($row = mysqli_fetch_assoc($result)){
    $data_members[] = $row;
}

$judul_halaman = "Kelola Data Member";

// 3. PANGGIL LAYOUT
include 'layout/header.php'; 
?>

<div class="bg-white rounded-lg shadow-lg overflow-hidden min-h-[500px]">
    
    <div class="p-5 border-b border-gray-200 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50">
        <h2 class="text-xl font-bold text-slate-800">
            <i class="fas fa-users text-blue-600 mr-2"></i> Daftar Member
        </h2>
        
        <form method="GET" class="flex w-full md:w-auto gap-2">
            <input type="text" name="keyword" value="<?php echo htmlspecialchars($keyword); ?>" 
                   class="flex-1 md:w-64 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm shadow-sm" 
                   placeholder="Cari Username / No HP...">
            
            <button type="submit" name="cari" class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition shadow-sm">
                <i class="fas fa-search"></i>
            </button>
            
            <?php if($keyword != ""): ?>
                <a href="kelola_member.php" class="bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition shadow-sm flex items-center justify-center">
                    <i class="fas fa-times"></i>
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="hidden md:block overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead class="bg-slate-100 text-slate-600 uppercase text-xs font-bold tracking-wider">
                <tr>
                    <th class="p-4 border-b">Member Info</th>
                    <th class="p-4 border-b">Kontak</th>
                    <th class="p-4 border-b">Bank</th>
                    <th class="p-4 border-b">Saldo</th>
                    <th class="p-4 border-b text-center">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-sm text-gray-700 divide-y divide-gray-100">
                <?php foreach($data_members as $row) { ?>
                <tr class="hover:bg-slate-50 transition">
                    <td class="p-4">
                        <div class="font-bold text-slate-800"><?php echo htmlspecialchars($row['username']); ?></div>
                        <div class="text-xs text-gray-400">Join: <?php echo date('d M Y', strtotime($row['tanggal_dibuat'])); ?></div>
                    </td>
                    <td class="p-4">
                        <div class="flex items-center gap-2"><i class="fas fa-phone text-slate-400 text-xs"></i> <?php echo htmlspecialchars($row['no_telpon']); ?></div>
                        <div class="flex items-center gap-2 mt-1"><i class="fas fa-envelope text-slate-400 text-xs"></i> <?php echo htmlspecialchars($row['email']); ?></div>
                    </td>
                    <td class="p-4">
                        <span class="bg-blue-100 text-blue-800 text-xs font-semibold px-2 py-1 rounded"><?php echo htmlspecialchars($row['nama_bank']); ?></span>
                        <div class="mt-1 text-gray-500 text-xs"><?php echo htmlspecialchars($row['nomor_bank']); ?></div>
                    </td>
                    <td class="p-4 font-bold text-green-600">Rp <?php echo number_format($row['saldo'], 0, ',', '.'); ?></td>
                    <td class="p-4 text-center">
                        <a href="edit_saldo.php?id=<?php echo $row['id']; ?>" class="bg-yellow-500 hover:bg-yellow-600 text-white text-xs font-bold py-2 px-3 rounded shadow transition">
                           <i class="fas fa-wallet mr-1"></i> Edit
                        </a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <div class="md:hidden bg-slate-50 p-4 space-y-4">
        <?php foreach($data_members as $row) { ?>
        <div class="bg-white p-4 rounded-lg shadow border border-gray-100 relative">
            
            <div class="flex justify-between items-start mb-3 border-b pb-2 border-dashed">
                <div>
                    <div class="font-bold text-lg text-slate-800"><?php echo htmlspecialchars($row['username']); ?></div>
                    <div class="text-xs text-gray-400"><?php echo date('d M Y, H:i', strtotime($row['tanggal_dibuat'])); ?></div>
                </div>
                <div class="text-right">
                    <div class="text-xs text-gray-500">Saldo</div>
                    <div class="font-bold text-green-600 text-lg">Rp <?php echo number_format($row['saldo'], 0, ',', '.'); ?></div>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-2 text-sm text-gray-600 mb-4">
                <div>
                    <span class="block text-xs text-gray-400">Telepon</span>
                    <i class="fas fa-phone-alt text-xs mr-1"></i> <?php echo htmlspecialchars($row['no_telpon']); ?>
                </div>
                <div>
                    <span class="block text-xs text-gray-400">Bank</span>
                    <span class="bg-blue-50 text-blue-600 px-1 rounded text-xs font-bold"><?php echo htmlspecialchars($row['nama_bank']); ?></span> <?php echo htmlspecialchars($row['nomor_bank']); ?>
                </div>
            </div>

            <a href="edit_saldo.php?id=<?php echo $row['id']; ?>" class="block w-full bg-yellow-500 text-white text-center py-2 rounded font-bold shadow hover:bg-yellow-600 transition">
                <i class="fas fa-wallet mr-2"></i> Edit Saldo
            </a>

        </div>
        <?php } ?>

        <?php if(empty($data_members)){ ?>
            <div class="text-center py-10 text-gray-500">
                <i class="fas fa-search text-4xl mb-3 text-gray-300"></i>
                <p>Tidak ada member ditemukan.</p>
            </div>
        <?php } ?>
    </div>
    
</div>

</main>
</div>
</div>
</body>
</html>
