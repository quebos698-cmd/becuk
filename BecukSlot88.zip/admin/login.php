<?php
session_start();
// Pastikan path ini sesuai dengan struktur folder Anda
include '../config/database.php';
include '../config/security_helper.php';

// Jika sudah login sebagai admin, langsung lempar ke dashboard
if(isset($_SESSION['role']) && $_SESSION['role'] == 'admin'){
    header("location:dashboard.php");
    exit;
}

$error = "";

if(isset($_POST['login'])){
    // 1. CEK KEAMANAN CSRF (Wajib)
    cek_csrf();

    // 2. TANGKAP INPUT
    $username = bersihkan_input($_POST['username']);
    $password = $_POST['password'];

    // 3. CEK DATABASE (Prepared Statement - Anti SQL Injection)
    $stmt = $koneksi->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0){
        $data = $result->fetch_assoc();
        
        // 4. VERIFIKASI PASSWORD
        // Jika Anda pakai user admin dari SQL Import saya, passwordnya: 123456
        if(password_verify($password, $data['password'])){
            
            // 5. SET SESSION
            session_regenerate_id(true); // Ganti ID sesi biar aman
            $_SESSION['user_id'] = $data['id'];
            $_SESSION['username'] = $data['username'];
            $_SESSION['role'] = $data['role'];

            // 6. REDIRECT SESUAI ROLE
            if($data['role'] == "admin"){
                header("location:dashboard.php");
                exit;
            } else {
                $error = "Akun Anda bukan Admin!";
            }
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username tidak ditemukan!";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - TopUp System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</head>
<body class="bg-slate-900 font-sans antialiased h-screen flex items-center justify-center px-4">

    <div class="max-w-md w-full bg-white rounded-lg shadow-2xl overflow-hidden">
        
        <div class="bg-blue-600 p-6 text-center">
            <h1 class="text-white text-2xl font-bold tracking-wider">ADMIN PANEL</h1>
            <p class="text-blue-200 text-sm mt-1">Silakan masuk untuk mengelola sistem</p>
        </div>

        <div class="p-8">
            
            <?php if($error != ""){ ?>
                <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 text-sm rounded relative" role="alert">
                    <span class="block sm:inline"><i class="fas fa-exclamation-triangle mr-1"></i> <?php echo $error; ?></span>
                </div>
            <?php } ?>

            <form method="POST" action="">
                <?php input_csrf_token(); ?>

                <div class="mb-5">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="username">Username</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-user text-gray-400"></i>
                        </div>
                        <input class="w-full pl-10 pr-3 py-3 border border-gray-300 rounded focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition" 
                               id="username" type="text" name="username" placeholder="Masukkan username" required autofocus>
                    </div>
                </div>

                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-bold mb-2" for="password">Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input class="w-full pl-10 pr-3 py-3 border border-gray-300 rounded focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition" 
                               id="password" type="password" name="password" placeholder="Masukkan password" required>
                    </div>
                </div>

                <div class="flex items-center justify-between mb-6">
                    <button class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded focus:outline-none focus:shadow-outline transition transform active:scale-95 shadow-lg" type="submit" name="login">
                        MASUK DASHBOARD <i class="fas fa-sign-in-alt ml-2"></i>
                    </button>
                </div>
            </form>

            <div class="text-center mt-4">
                <a href="../index.php" class="text-sm text-gray-500 hover:text-blue-600">Kembali ke Beranda</a>
            </div>
        </div>
    </div>

</body>
</html>
