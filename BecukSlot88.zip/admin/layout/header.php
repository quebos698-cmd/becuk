<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - TopUp System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" />
</head>
<body class="bg-slate-100 font-sans antialiased">
    
    <div id="sidebarOverlay" onclick="toggleSidebar()" class="fixed inset-0 bg-black opacity-50 z-40 hidden md:hidden"></div>

    <div class="flex h-screen overflow-hidden">
        
<?php include __DIR__ . '/sidebar.php'; ?>


        <div class="flex-1 flex flex-col md:ml-0 transition-all duration-300">
            
            <header class="bg-white shadow-sm h-16 flex items-center justify-between px-6 z-30 sticky top-0">
                <div class="flex items-center gap-4">
                    <button onclick="toggleSidebar()" class="text-slate-600 focus:outline-none md:hidden">
                        <i class="fas fa-bars text-2xl"></i>
                    </button>
                    
                    <div class="font-bold text-xl text-slate-800">
                        <?php echo isset($judul_halaman) ? $judul_halaman : 'Admin Panel'; ?>
                    </div>
                </div>

                <div class="text-slate-600 text-sm">
                    <span class="hidden md:inline">Status: <span class="text-green-600 font-bold">Aman <i class="fas fa-shield-alt"></i></span> | </span>
                    Halo, <span class="font-bold text-blue-600"><?php echo htmlspecialchars($_SESSION['username']); ?></span>
                </div>
            </header>

            <script>
                function toggleSidebar() {
                    const sidebar = document.getElementById('sidebar');
                    const overlay = document.getElementById('sidebarOverlay');
                    
                    // Logic: Jika ada class -translate-x-full, hapus (biar muncul). Jika tidak ada, tambah (biar hilang).
                    if (sidebar.classList.contains('-translate-x-full')) {
                        sidebar.classList.remove('-translate-x-full'); // Munculkan Menu
                        overlay.classList.remove('hidden'); // Munculkan Layar Gelap
                    } else {
                        sidebar.classList.add('-translate-x-full'); // Sembunyikan Menu
                        overlay.classList.add('hidden'); // Sembunyikan Layar Gelap
                    }
                }
            </script>

            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 p-6">
