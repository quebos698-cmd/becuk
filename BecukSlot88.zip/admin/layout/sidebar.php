<aside id="sidebar" class="bg-slate-900 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out z-50 h-screen overflow-y-auto">
    
    <div class="flex items-center justify-between px-4 mb-6 border-b border-slate-700 pb-4">
        <span class="text-2xl font-extrabold tracking-wider">ADMIN</span>
        <button onclick="toggleSidebar()" class="md:hidden text-slate-400 hover:text-white focus:outline-none">
            <i class="fas fa-times text-2xl"></i>
        </button>
    </div>

    <nav class="space-y-2">
        <a href="dashboard.php" class="block py-3 px-4 rounded hover:bg-blue-600 transition <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'bg-blue-600' : 'text-slate-300'; ?>">
            <i class="fas fa-home w-6"></i> Dashboard
        </a>
        <a href="kelola_member.php" class="block py-3 px-4 rounded hover:bg-blue-600 transition <?php echo basename($_SERVER['PHP_SELF']) == 'kelola_member.php' ? 'bg-blue-600' : 'text-slate-300'; ?>">
            <i class="fas fa-users w-6"></i> Data Member
        </a>
        <a href="riwayat_transaksi.php" class="block py-3 px-4 rounded hover:bg-blue-600 transition <?php echo basename($_SERVER['PHP_SELF']) == 'riwayat_transaksi.php' ? 'bg-blue-600' : 'text-slate-300'; ?>">
            <i class="fas fa-history w-6"></i> Riwayat Transaksi
        </a>
        
        <div class="pt-10"></div>
        
        <a href="logout.php" class="block py-3 px-4 rounded hover:bg-red-900 transition text-red-400 border border-transparent hover:border-red-800">
            <i class="fas fa-sign-out-alt w-6"></i> Logout
        </a>
    </nav>
</aside>
