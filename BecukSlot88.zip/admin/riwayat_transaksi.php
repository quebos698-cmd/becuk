<?php
// 1. SETUP
session_start();
include '../config/database.php';
include '../config/security_helper.php';

// Cek Admin
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("location:login.php");
    exit;
}

// 2. LOGIKA FILTER
$where_clause = "WHERE 1=1"; // Default: Ambil semua

// Filter Tanggal
$tgl_mulai = isset($_GET['tgl_mulai']) ? $_GET['tgl_mulai'] : date('Y-m-01'); // Default awal bulan
$tgl_akhir = isset($_GET['tgl_akhir']) ? $_GET['tgl_akhir'] : date('Y-m-d');  // Default hari ini

if(isset($_GET['filter'])){
    $tgl_mulai = $_GET['tgl_mulai'];
    $tgl_akhir = $_GET['tgl_akhir'];
    $tipe = $_GET['tipe'];

    // Filter Range Tanggal
    $where_clause .= " AND DATE(r.tanggal) BETWEEN '$tgl_mulai' AND '$tgl_akhir'";

    // Filter Tipe (Jika bukan 'semua')
    if($tipe != 'semua'){
        $where_clause .= " AND r.tipe_transaksi = '$tipe'";
    }
}

// 3. QUERY DATA (JOIN dengan tabel users biar tahu siapa yang transaksi)
$query = "SELECT r.*, u.username 
          FROM riwayat_transaksi r 
          JOIN users u ON r.user_id = u.id 
          $where_clause 
          ORDER BY r.tanggal DESC";

$result = mysqli_query($koneksi, $query);

// Simpan data ke array (untuk Dual View)
$transaksi = [];
while($row = mysqli_fetch_assoc($result)){
    $transaksi[] = $row;
}

// Hitung Total Masuk & Keluar di filter ini
$total_masuk = 0;
$total_keluar = 0;
foreach($transaksi as $t){
    if($t['tipe_transaksi'] == 'masuk') $total_masuk += $t['jumlah'];
    else $total_keluar += $t['jumlah'];
}

$judul_halaman = "Riwayat Transaksi";
include 'layout/header.php';
?>

<div class="space-y-6">

    <div class="bg-white rounded-lg shadow p-4">
        <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
            
            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Dari Tanggal</label>
                <input type="date" name="tgl_mulai" value="<?php echo $tgl_mulai; ?>" 
                       class="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Sampai Tanggal</label>
                <input type="date" name="tgl_akhir" value="<?php echo $tgl_akhir; ?>" 
                       class="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Tipe</label>
                <select name="tipe" class="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white">
                    <option value="semua" <?php echo (isset($_GET['tipe']) && $_GET['tipe'] == 'semua') ? 'selected' : ''; ?>>Semua Tipe</option>
                    <option value="masuk" <?php echo (isset($_GET['tipe']) && $_GET['tipe'] == 'masuk') ? 'selected' : ''; ?>>Uang Masuk (+)</option>
                    <option value="keluar" <?php echo (isset($_GET['tipe']) && $_GET['tipe'] == 'keluar') ? 'selected' : ''; ?>>Uang Keluar (-)</option>
                </select>
            </div>

            <button type="submit" name="filter" class="bg-blue-600 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 transition h-10 w-full md:w-auto">
                <i class="fas fa-filter mr-2"></i> Terapkan
            </button>
        </form>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div class="bg-emerald-100 p-4 rounded-lg border border-emerald-200">
            <p class="text-xs text-emerald-600 font-bold uppercase">Total Masuk</p>
            <p class="text-lg md:text-xl font-bold text-emerald-700">+ Rp <?php echo number_format($total_masuk, 0, ',', '.'); ?></p>
        </div>
        <div class="bg-red-100 p-4 rounded-lg
