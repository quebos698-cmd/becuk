<?php
session_start();
include '../config/database.php';

// 1. CEK LOGIN ADMIN
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("location:../member/login.php");
    exit;
}

// 2. AMBIL ID MEMBER DARI URL
if(!isset($_GET['id']) || empty($_GET['id'])){
    echo "<script>alert('Error: ID Member tidak ditemukan!'); window.location.href='dashboard.php';</script>";
    exit;
}

$id_target = mysqli_real_escape_string($koneksi, $_GET['id']);
$pesan = "";

// 3. PROSES INJECT SALDO (UBAH LANGSUNG)
if(isset($_POST['inject_saldo'])){
    $saldo_baru = (int)str_replace('.', '', $_POST['saldo_baru']);
    
    // Update Saldo di Tabel Users
    $update = mysqli_query($koneksi, "UPDATE users SET saldo = '$saldo_baru' WHERE id='$id_target'");
    
    if($update){
        $ket = "Inject Saldo Admin";
        mysqli_query($koneksi, "INSERT INTO riwayat_transaksi (user_id, tipe_transaksi, jumlah, keterangan, status, tanggal) VALUES ('$id_target', 'masuk', '0', '$ket', 'sukses', NOW())");
        
        $pesan = "<div class='alert alert-success fw-bold'>SUKSES! Saldo member berubah menjadi Rp ".number_format($saldo_baru)."</div>";
    } else {
        $pesan = "<div class='alert alert-danger'>Gagal update database.</div>";
    }
}

// 4. PROSES ACC/TOLAK TRANSAKSI PENDING (PERBAIKAN BUG)
if(isset($_POST['proses_pending'])){
    $id_trx = $_POST['id_trx'];
    // PERBAIKAN DI SINI: Mengambil value dari tombol yang diklik (terima/tolak)
    $aksi   = $_POST['proses_pending']; 
    
    $cek = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE id='$id_trx'");
    $dt  = mysqli_fetch_assoc($cek);
    
    if($dt){
        $nominal = $dt['jumlah'];
        $tipe    = $dt['tipe_transaksi'];
        
        if($aksi == 'terima'){
            // --- JIKA DITERIMA (ACC) ---
            if($tipe == 'masuk'){
                // Jika deposit, tambah saldo user
                mysqli_query($koneksi, "UPDATE users SET saldo = saldo + $nominal WHERE id='$id_target'");
            }
            // Update status transaksi jadi sukses
            mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status='sukses', keterangan=CONCAT(keterangan, ' [ACC]') WHERE id='$id_trx'");
            $pesan = "<div class='alert alert-success fw-bold'>Transaksi berhasil di-ACC.</div>";
            
        } else {
            // --- JIKA DITOLAK ---
            if($tipe == 'keluar'){
                // Jika withdraw ditolak, kembalikan saldo ke user
                mysqli_query($koneksi, "UPDATE users SET saldo = saldo + $nominal WHERE id='$id_target'");
            }
            // Update status transaksi jadi batal
            mysqli_query($koneksi, "UPDATE riwayat_transaksi SET status='batal', keterangan=CONCAT(keterangan, ' [Ditolak]') WHERE id='$id_trx'");
            $pesan = "<div class='alert alert-warning fw-bold'>Transaksi berhasil DITOLAK.</div>";
        }
    }
}

// 5. AMBIL DATA USER TERBARU (REFRESH SETELAH UPDATE)
$q_user = mysqli_query($koneksi, "SELECT * FROM users WHERE id='$id_target'");
$data_user = mysqli_fetch_assoc($q_user);

if(!$data_user){
    echo "Member tidak ditemukan."; exit;
}

// Ambil Transaksi Pending
$pending = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_target' AND status='pending'");

// Ambil History
$history = mysqli_query($koneksi, "SELECT * FROM riwayat_transaksi WHERE user_id='$id_target' ORDER BY id DESC LIMIT 10");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inject Saldo - <?php echo $data_user['username']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background: #f8f9fa; font-family: sans-serif; }
        .card-header { font-weight: bold; text-transform: uppercase; background: #343a40; color: #fff; }
        .btn-inject { background: #28a745; color: #fff; font-weight: bold; border:none; padding: 12px; font-size: 18px; }
        .btn-inject:hover { background: #218838; color: #fff; }
        .text-saldo { font-size: 30px; font-weight: bold; color: #007bff; }
    </style>
</head>
<body>

<div class="container mt-5 mb-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3><i class="fa fa-bolt"></i> PANEL INJECT SALDO</h3>
        <button onclick="history.back()" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> KEMBALI</button>
    </div>

    <?php echo $pesan; ?>

    <div class="row">
        <div class="col-md-4">
            <div class="card shadow-sm mb-3">
                <div class="card-header text-center">DATA MEMBER</div>
                <div class="card-body text-center">
                    <h2 class="mb-0"><?php echo $data_user['username']; ?></h2>
                    <hr>
                    <small>SISA SALDO</small>
                    <div class="text-saldo">Rp <?php echo number_format($data_user['saldo']); ?></div>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            
            <?php if(mysqli_num_rows($pending) > 0): ?>
            <div class="card border-warning mb-3">
                <div class="card-header bg-warning text-dark"><i class="fa fa-clock"></i> MENUNGGU PERSETUJUAN (PENDING)</div>
                <div class="card-body p-0">
                    <table class="table table-striped mb-0">
                        <?php while($row = mysqli_fetch_assoc($pending)): ?>
                        <tr>
                            <td>
                                <b><?php echo strtoupper($row['tipe_transaksi'] == 'masuk' ? 'DEPOSIT' : 'WITHDRAW'); ?></b><br>
                                <span class="text-muted">Rp <?php echo number_format($row['jumlah']); ?></span>
                            </td>
                            <td><?php echo $row['keterangan']; ?></td>
                            <td class="text-end">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="id_trx" value="<?php echo $row['id']; ?>">
                                    <button type="submit" name="proses_pending" value="terima" class="btn btn-success btn-sm fw-bold">ACC</button>
                                    <button type="submit" name="proses_pending" value="tolak" class="btn btn-danger btn-sm fw-bold">TOLAK</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-header"><i class="fa fa-edit"></i> UBAH SALDO MEMBER</div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="fw-bold">SET SALDO MENJADI (RP)</label>
                            <input type="text" name="saldo_baru" class="form-control form-control-lg fw-bold border-primary" placeholder="0" onkeyup="formatRupiah(this)" required>
                            <div class="form-text text-danger">*Hati-hati! Saldo akan langsung berubah ke angka yang Anda masukkan.</div>
                        </div>
                        <button type="submit" name="inject_saldo" class="btn btn-inject w-100" onclick="return confirm('Yakin ingin mengubah saldo member ini?')">
                            SIMPAN SALDO
                        </button>
                    </form>
                </div>
            </div>

        </div>
    </div>

    <div class="card mt-4">
        <div class="card-header">RIWAYAT TRANSAKSI TERAKHIR</div>
        <div class="table-responsive">
            <table class="table table-bordered mb-0 table-sm">
                <thead>
                    <tr class="bg-light">
                        <th>Tanggal</th>
                        <th>Tipe</th>
                        <th>Jumlah</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($h = mysqli_fetch_assoc($history)): ?>
                    <tr>
                        <td><?php echo $h['tanggal']; ?></td>
                        <td><?php echo strtoupper($h['tipe_transaksi']); ?></td>
                        <td class="fw-bold">Rp <?php echo number_format($h['jumlah']); ?></td>
                        <td><?php echo $h['keterangan']; ?></td>
                        <td><b><?php echo strtoupper($h['status']); ?></b></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
    function formatRupiah(el) {
        let angka = el.value.replace(/\./g, '');
        if (!/^\d+$/.test(angka)) { el.value = angka.substring(0, angka.length - 1); return; }
        el.value = new Intl.NumberFormat('id-ID').format(angka);
    }
</script>

</body>
</html>
