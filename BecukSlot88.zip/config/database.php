<?php
// Konfigurasi Database
$host = "0.0.0.0";
$user = "root";         // Default XAMPP/Laragon biasanya 'root'
$pass = "root";             // Default biasanya kosong
$db   = "db_topup";     // GANTI dengan nama database yang Anda buat di phpMyAdmin

// Membuat Koneksi
$koneksi = mysqli_connect($host, $user, $pass, $db);

// Cek Koneksi
if (!$koneksi) {
    // Jika gagal, stop loading dan tampilkan pesan error
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}
?>
