<?php
// 1. PENGATURAN SESI AMAN
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    session_start();
}

// --- BAGIAN RATE LIMITER DIHAPUS SEMENTARA ---
// Agar tidak mengganggu proses development/testing Anda.
// ---------------------------------------------

// 2. CSRF PROTECTION (Tiket Keamanan Form)
if (empty($_SESSION['csrf_token'])) {
    try {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    } catch (Exception $e) {
        // Fallback jika random_bytes gagal
        $_SESSION['csrf_token'] = bin2hex(openssl_random_pseudo_bytes(32));
    }
}

// Fungsi Panggil di Form HTML
function input_csrf_token() {
    echo '<input type="hidden" name="csrf_token" value="' . $_SESSION['csrf_token'] . '">';
}

// Fungsi Cek di Proses PHP
function cek_csrf() {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        // Reset token jika invalid untuk mencegah looping error
        unset($_SESSION['csrf_token']);
        die("KESALAHAN KEAMANAN: Token CSRF tidak valid! Silakan refresh halaman.");
    }
}

// 3. BERSIHKAN INPUT (Anti XSS)
function bersihkan_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>
